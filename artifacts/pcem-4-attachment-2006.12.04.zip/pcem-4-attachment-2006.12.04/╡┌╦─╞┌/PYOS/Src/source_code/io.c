/* ���˿� */
unsigned char io_read_from_io_port( unsigned short port_number )
{
  /* 
     % ��ʾ���ǼĴ���
     =a(result) ��ʾ�� result = ax
	   d(port_number) ��ʾ�� dx = port_number 
  */
  unsigned char result ;
  __asm__( "in %%dx , %%al" : "=a"( result ) : "d"( port_number ) ) ;
  return result ;
}

/* д�˿� */
void io_write_to_io_port( unsigned short port_number , unsigned char data )
{
  __asm__( "out %%al , %%dx" : : "a"( data ) , "d"( port_number ) ) ;
}
