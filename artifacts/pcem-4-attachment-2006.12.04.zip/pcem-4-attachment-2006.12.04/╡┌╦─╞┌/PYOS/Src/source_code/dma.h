#ifndef _PYOS_DMA_H_
#define _PYOS_DMA_H_

enum dma_read_or_write_model_enum{ DMA_READ_MODEL = 1 , DMA_WRITE_MODEL } ;

void dma_init() ;

void dma_open_dma_channel( unsigned char dma_channel , void* start_address_in_memory ,  unsigned short count , enum dma_read_or_write_model_enum read_or_write_model ) ;

void dma_close_dma_channel( unsigned char dma_channel ) ;

#endif 
