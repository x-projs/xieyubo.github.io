#ifndef _PYOS_VESA_H_
#define _PYOS_VESA_H_

/***********************************
* vesa ��������                    *
* ���ڴ������� 800 * 600 ( 5:5:5 ) *
***********************************/

extern const int VESA_SCREEN_X_MAX ;
extern const int VESA_SCREEN_Y_MAX ;

// ɫ���ϳɺ���
unsigned short vesa_compond_rgb( unsigned char r , unsigned char g , unsigned char b ) ;

// ɫ��ת���������� 5:5:5 ��ʽת���ɱ�׼�� 5:6:5 ��ʽ
unsigned short vesa_change_color_form_555_to_565( unsigned short color_form_555 ) ;

// ���㺯��
void vesa_draw_point( unsigned int x , unsigned int y , unsigned short color ) ;

// ������亯��
void vesa_fill_rect( unsigned int x1 , unsigned int y1 , unsigned int x2 , unsigned int y2 , unsigned int color ) ;

// ��������
void vesa_clean_screen( unsigned short color ) ;

// �����ߺ���
void vesa_draw_x_line( unsigned int y , unsigned int x1 , unsigned int x2 , unsigned short color ) ;
// �����ߺ���
void vesa_draw_y_line( unsigned int x , unsigned int y1 , unsigned int y2 , unsigned short color ) ;
// �����κ���
void vesa_draw_rect( unsigned int x1 , unsigned int y1 , unsigned int x2 , unsigned y2 , unsigned short color , int dose_fill_it ) ; 

// ��ʾӢ��
void vesa_print_english( unsigned int x , unsigned int y , unsigned int pos_in_font , unsigned short color ) ;

// ��ʾ����
void vesa_print_chinese( unsigned int x , unsigned int y , unsigned int pos_in_font , unsigned short color ) ;

// ��ʾ bmp ��ʽ��ͼƬ
void vesa_show_bmp_picture( unsigned int x , unsigned int y , void *bmp_addr , unsigned short mask_color , int dose_use_mask_color ) ;

// ��ʾ�ַ�
void vesa_print_char_under_text_model( char x ) ;

// ͼƬ��������
void vesa_copy_picture_from_screen( unsigned int x , unsigned int y , unsigned short *object_picture_addr , unsigned int picture_width , unsigned int picture_height ) ;

// ͼƬ��������
void vesa_copy_picture_to_screen( unsigned int x , unsigned int y , unsigned short *source_picture_addr , unsigned int picture_width , unsigned int pictrue_height ) ;
// ȡ��ָ����ɫ��
unsigned short vesa_get_point_color( unsigned int x , unsigned int y ) ;

int vesa_does_point_in_rect( int x , int y , int x1 , int y1 , int x2 , int y2 ) ;

void vesa_print_string( char *string , int x , int y , unsigned short color ) ;

void vesa_print_number( int number , int x , int y , unsigned short color ) ;

void vesa_show_bmp_picture_in_rect( int x1 , int y1 , int x2 , int y2 , void *bmp_addr , unsigned short mask_color , int dose_use_mask_color , int x_offset , int y_offset ) ;

void vesa_print_string_in_rect( char *string , int x1 , int y1 , int x2 , int y2 , unsigned short color , int x_offset , int y_offset ) ;

void vesa_read_bmp_information( void *bmp_address , int *bmp_length , int *bmp_height ) ;

#endif
