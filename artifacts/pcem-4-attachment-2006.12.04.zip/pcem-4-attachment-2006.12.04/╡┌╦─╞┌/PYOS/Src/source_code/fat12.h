#ifndef _PYOS_FAT12_H_
#define _PYOS_FAT12_H_

void fat12_init( void *fat_table_buffer_address ) ;
void fat12_load_file( char *file_name , void *object_address ) ;
void fat12_read_information( unsigned int *free_space ) ;
void fat12_translate_full_file_name_to_short_file_name( char *full_file_name , char *short_file_name , int *file_name_length ) ;

struct fat12_file_attribute_struct{
  char full_name[ 11 ] ;
  char attribute ;
  char reserved0 ;
  char create_time_ms ;
  unsigned short create_time ;
  unsigned short create_date ;
  unsigned short access_date ;
  unsigned short start_cluster_hi16 ;
  unsigned short update_time ;
  unsigned short update_date ;
  unsigned short start_cluster_lo16 ;
  unsigned int how_many_byte ;
} ;

#endif
