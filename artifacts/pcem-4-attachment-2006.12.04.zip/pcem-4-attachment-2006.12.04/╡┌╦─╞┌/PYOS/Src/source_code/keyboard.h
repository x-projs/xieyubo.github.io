#ifndef _PYOS_KEYBOARD_H_
#define _PYOS_KEYBOARD_H_

void keyboard_init() ;

#endif
