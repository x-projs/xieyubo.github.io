#include "memory.h"

void memory_copy( void *source_address , void *object_address , unsigned int how_many_byte )
{
  unsigned char *o = ( unsigned char * )object_address ;
  unsigned char *s = ( unsigned char * )source_address ;

  for( unsigned int i = 0 ; i < how_many_byte ; ++i ){
    o[ i ] = s[ i ] ;
  }
}

int memory_is_equal( void *address1 , void *address2 , unsigned int how_many_byte )
{
  unsigned char *p1 = address1 ;
  unsigned char *p2 = address2 ;
  while( how_many_byte-- ){
    if( *p1++ != *p2++ ){
      return 0 ;
    }
  }
  return 1 ;
}
