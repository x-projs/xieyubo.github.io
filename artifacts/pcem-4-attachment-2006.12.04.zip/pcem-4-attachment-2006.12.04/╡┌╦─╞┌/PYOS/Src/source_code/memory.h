#ifndef _PYOS_MEMORY_H_
#define _PYOS_MEMORY_H_

void memory_copy( void *source_address , void *object_address , unsigned int how_many_byte ) ;
int memory_is_equal( void *address1 , void *address2 , unsigned int how_many_byte ) ;

#endif
