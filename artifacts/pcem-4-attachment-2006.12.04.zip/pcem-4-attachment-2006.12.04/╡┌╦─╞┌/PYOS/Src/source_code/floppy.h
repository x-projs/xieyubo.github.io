#ifndef _PYOS_FLOPPY_H_
#define _PYOS_FLOPPY_H_

void floppy_init( void *buffer_address ) ;
void floppy_write( unsigned char sector , unsigned char cylinder , unsigned char head , void * source_address ) ;
void floppy_read_via_address( void *address_in_floppy , void *address_in_memory , unsigned int how_many_byte ) ; 
void floppy_read( unsigned char sector , unsigned char cylinder , unsigned char head ) ;
void floppy_send_read_command(unsigned char head, unsigned char cylinder, unsigned char sector);

#endif
