#ifndef _PYOS_KERNEL_H_
#define _PYOS_KERNEL_H_

#include "message.h" 

/* �ں���Ϣ���� */
extern struct message_message_queue_struct kernel_message_queue ;

struct kernel_file_list_struct{
  int count ;
  char full_name[ 0xe0 ][ 11 ] ;
  int pos[ 0xe0 ] ;
  int pic_pos[ 0xe0 ][ 2 ] ;
  int size[ 0xe0 ] ;
} ;

extern struct kernel_file_list_struct *kernel_file_list ;

#endif 
