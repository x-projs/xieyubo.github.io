#include "string.h"

int string_is_equal( char *string1 , char *string2 )
{
  char *p1 = string1 ;
  char *p2 = string2 ;
  while( *p1 && *p1++ == *p2++ ) ;
  return !( *p1 || *p2 ) ;
}
