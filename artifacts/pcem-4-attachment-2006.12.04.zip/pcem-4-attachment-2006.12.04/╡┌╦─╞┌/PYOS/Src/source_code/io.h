#ifndef _PYOS_IO_H_
#define _PYOS_IO_H

/* ���˿� */
unsigned char io_read_from_io_port( unsigned short port_number ) ;

/* д�˿� */
void io_write_to_io_port( unsigned short port_number , unsigned char data ) ;

#endif
