#ifndef _PYOS_STRING_H_
#define _PYOS_STRING_H_

int string_is_equal( char *string1 , char *string2 ) ;

#endif
