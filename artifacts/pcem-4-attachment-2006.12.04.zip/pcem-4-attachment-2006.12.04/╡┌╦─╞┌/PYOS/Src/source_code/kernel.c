#include "system.h"
#include "vesa.h"
#include "mouse.h"
#include "interrupt.h"
#include "message.h"
#include "floppy.h"
#include "fat12.h"
#include "kernel.h"
#include "memory.h"

/******************************************************
* ��������                                            *
******************************************************/

enum kernel_kernel_state_enum{ KERNEL_WAIT_USER_LOGIN , KERNEL_USER_LOGED_IN , KERNEL_OPEN_FLOPPY , KERNEL_VIEW } ;
enum kernel_file_type_enum{ BMP_FILE , TXT_FILE , BIN_FILE , OTHER_FILE , FNT_FILE } ;

static void kernel_draw_login_form() ;
static void kernel_start_picsee() ;
static void kernel_draw_picsee( int x , int y ) ;
static void kernel_open_file( int file_number ) ;
static void kernel_close_file() ;
static enum kernel_file_type_enum kernel_get_file_type( char *full_file_name ) ;
static void kernel_logout() ;

static enum kernel_file_type_enum kernel_opened_file_type ;

/******************************************************
* ���ݶ��岿��                                        *
******************************************************/

static int kernel_mouse_x_position = 444 ;
static int kernel_mouse_y_position = 300 ;

static enum mouse_type_enum kernel_mouse_type = MOUSE_NORMAL_MOUSE ;
static enum kernel_kernel_state_enum kernel_kernel_state = KERNEL_WAIT_USER_LOGIN ; 

struct message_message_queue_struct kernel_message_queue ;

struct kernel_file_list_struct *kernel_file_list = ( void * )0x200000 ;

/* Ӧ�ó���ͼ��λ�� */
static int mycomputer_picture_x ;
static int mycomputer_picture_y ;

static unsigned short *old_picture = ( unsigned short * )0x300000 ;
static unsigned short *file_picture = ( unsigned short * )0x400000 ;

static int picsee_x ;
static int picsee_y ;

static int kernel_file_from = 0 ;
static char kernel_file_name[ 6 ][ 12 ] ;
static int kernel_file_index[ 6 ] ;

static unsigned int kernel_floppy_free_space ;
static int kernel_start_file_number ;
static int kernel_draw_file_count ;

static int kernel_file_show_x_offset = 0 ;
static int kernel_file_show_y_offset = 0 ;

void kernel_logout()
{
  // �ð�ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_clean_screen( color ) ;  

  // ��ʾ�˳�ͼƬ( 246 * 103 )
  vesa_show_bmp_picture( 277 , 248 , ( void * )0x1b0000 , 0 , 0 ) ;

  // ���ж�
  interrupt_close_interrupt() ;

  // �����Ϣ����
  message_init_message_queue( &kernel_message_queue ) ;

  // �����˳���Ϣ
  struct message_message_struct message ;
  message.message_type = MESSAGE_SHUTDOWN_COMPUTER ;
  message_put_message( &kernel_message_queue , message ) ;
}

void kernel_close_file()
{
  // �ָ������ͼƬ
  vesa_copy_picture_to_screen( 50 , 20 , file_picture , 50 + 700 , 20 + 530 ) ;
  // ����һ�� mouse �µ�ͼƬ
  mouse_save_picture( kernel_mouse_x_position , kernel_mouse_y_position ) ;
  kernel_kernel_state = KERNEL_OPEN_FLOPPY ;
}

void kernel_show_file()
{
  // ����ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_draw_rect( 50 + 145 , 20 + 5  , 50 + 145 + 550 , 20 + 5 + 520 , color , 1 ) ;

  if( kernel_opened_file_type == BMP_FILE ){
    vesa_show_bmp_picture_in_rect( 50 + 145 , 20 + 5 , 50 + 145 + 550 , 20 + 5 + 520 , ( void * )0x500000 , 0 , 0 , kernel_file_show_x_offset , kernel_file_show_y_offset ) ;
  }
  else if( kernel_opened_file_type == TXT_FILE ){
    vesa_print_string_in_rect( ( void * )0x500000 , 50 + 145 , 20 + 5 , 50 + 145 + 550 , 20 + 5 + 520 , 0 , kernel_file_show_x_offset , kernel_file_show_y_offset ) ;
  }
  else{
    vesa_print_string( "Sorry, ���汾�� Pyos ���޷����������͵��ļ� :(" , 50 + 145 , 20 + 5 , 0 ) ;
  }
}

void kernel_open_file( int file_number )
{
  kernel_file_show_x_offset = 0 ;
  kernel_file_show_y_offset = 0 ;

  // �Ȼָ�һ�� mouse �б����ͼ
  mouse_restore_picture( kernel_mouse_x_position , kernel_mouse_y_position ) ;

  // ����ԭ����
  vesa_copy_picture_from_screen( 50 , 20 , file_picture , 50 + 700 , 20 + 530 ) ;
  
  // ����ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_draw_rect( 50 , 20 , 50 + 700 , 20 + 530 , color , 1 ) ;

  // �����ο�
  color = vesa_compond_rgb( 0 , 0 , 255 ) ;
  vesa_draw_rect( 50 , 20 , 50 + 700 , 20 + 530 , color , 0 ) ;
  vesa_draw_rect( 50 + 1  , 20 + 1 , 50 + 700 - 1 , 20 + 530 - 1 , color , 0 ) ;

  // ������
  vesa_draw_y_line( 50 + 140 , 20 , 20 + 530 , color ) ;

  // ��ʾ close ͼƬ
  vesa_show_bmp_picture( 50 + 70 - 50 , 20 + 530 - 105 , ( void * )0x1ab100 , 0 , 0 ) ;

  // ��ʾ��ť
  vesa_show_bmp_picture( 50 + 22 + 32 , 20 + 217 , ( void * )0x1a5000 , 0 , 0 ) ;
  vesa_show_bmp_picture( 50 + 22 + 32 , 20 + 217 + 32 + 32 , ( void * )0x1a6000 , 0 , 0 ) ;
  vesa_show_bmp_picture( 50 + 22 , 20 + 217 + 32 , ( void * )0x1a7000 , 0 , 0 ) ;
  vesa_show_bmp_picture( 50 + 22 + 32 + 32 , 20 + 217 + 32 , ( void * )0x1a8000 , 0 , 0 ) ;

  // ��ʾ�ļ�ժҪ��Ϣ
  char file_name[ 12 ] ;
  int length ;
  fat12_translate_full_file_name_to_short_file_name( kernel_file_list->full_name[ file_number ] , file_name , &length ) ;
  vesa_print_string( "�ļ���:" , 55 , 25 , 0 ) ;
  vesa_print_string( "    " , 55 , 45 , 0 ) ;
  vesa_print_string( file_name , 55 + 32 , 45 , 0 ) ;

  vesa_print_string( "�ļ���С:" , 55 , 65 , 0 ) ;
  vesa_print_string( "    " , 55 , 85 , 0 ) ;
  vesa_print_number( kernel_file_list->size[ file_number ] , 55 + 32 , 85 , 0 ) ;

  vesa_print_string( "�ļ�����:" , 55 , 105 , 0 ) ;
  vesa_print_string( "    " , 55 , 125 , 0 ) ;
  kernel_opened_file_type = kernel_get_file_type( kernel_file_list->full_name[ file_number ] ) ;

  vesa_print_string( "�ļ������У����Ե�~~~" , 50 + 145 , 20 + 5 , 0 ) ;

  switch( kernel_opened_file_type ){
    case BMP_FILE :
      vesa_print_string( "λͼ�ļ�" , 55 + 32 , 125 , 0 ) ;

      // �����ļ�
      fat12_load_file( file_name , ( void * )0x500000 ) ;

      int bmp_length , bmp_height ;
      vesa_read_bmp_information( ( void * )0x500000 , &bmp_length , &bmp_height ) ;
      
      vesa_print_string( "��:" , 55 , 145 , 0 ) ;
      vesa_print_string( "    " , 55 , 165 , 0 ) ;
      vesa_print_number( bmp_length , 55 + 32 , 165 , 0 ) ;

      vesa_print_string( "��:" , 55 , 185 , 0 ) ;
      vesa_print_string( "    " , 55 , 205 , 0 ) ;
      vesa_print_number( bmp_height , 55 + 32 , 205 , 0 ) ;
      break ;

    case TXT_FILE :
      vesa_print_string( "�ı��ļ�" , 55 + 32 , 125 , 0 ) ;
      // �����ļ�
      fat12_load_file( file_name , ( void * )0x500000 ) ;
      // �����һ�ֽ���Ϊ 0
      *( ( char * )0x500000 + kernel_file_list->size[ file_number ] ) = 0 ;
      break ;

    case BIN_FILE :
      vesa_print_string( "�������ļ�" , 55 + 32 , 125 , 0 ) ;
      break ;

    case FNT_FILE :
      vesa_print_string( "�ֿ��ļ�" , 55 + 32 , 125 , 0 ) ;
      break ;

    default :
      vesa_print_string( "δ֪����" , 55 + 32 , 125 , 0 ) ;
  }
  kernel_show_file() ;

  // ��ʾ mouse , ��Ϊ�����ڻ�����ʱ��ס�� mouse
  mouse_show_mouse( kernel_mouse_x_position , kernel_mouse_y_position , kernel_mouse_type ) ;

  kernel_kernel_state = KERNEL_VIEW ;
}

enum kernel_file_type_enum kernel_get_file_type( char *full_file_name )
{
  if( memory_is_equal( "BMP" , &full_file_name[ 8 ] , 3 ) ){
    return BMP_FILE ;
  }
  else if( memory_is_equal( "TXT" , &full_file_name[ 8 ] , 3 ) ){
    return TXT_FILE ;
  }
  else if( memory_is_equal( "BIN" , &full_file_name[ 8 ] , 3 ) ){
    return BIN_FILE ;
  }
  else if( memory_is_equal( "FNT" , &full_file_name[ 8 ] , 3 ) ){
    return FNT_FILE ;
  }
  else{
    return OTHER_FILE ;
  }
}

// ����Ϸ
void kernel_draw_picsee( int x , int y )
{
  // �Ȼָ� mouse �б����ͼ
  mouse_restore_picture( kernel_mouse_x_position , kernel_mouse_y_position ) ;

  // ����ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_draw_rect( x , y , x + 356 , y + 372 , color , 1 ) ;

  // �����ο�
  color = vesa_compond_rgb( 0 , 0 , 255 ) ;
  vesa_draw_rect( x , y , x + 356 , y + 372 , color , 0 ) ;
  vesa_draw_rect( x + 1  , y + 1 , x + 356 - 1 , y + 372 - 1 , color , 0 ) ;

  // ����
  vesa_show_bmp_picture( x + 2 , y + 2 , ( void * )0x199000 , 0 , 0 ) ;

  // ��ʾժҪ
  vesa_show_bmp_picture( x + 60 - 48 / 2 , y + 20 , ( void * )0x1a3000 , 0 , 0 ) ;
  color = vesa_compond_rgb( 0 , 0 , 0 ) ;
  
  vesa_print_string( "�����ļ�:" , x + 5 , y + 80 , color ) ;
  vesa_print_string( "    " , x + 5 , y + 100 , color ) ;
  vesa_print_number( kernel_file_list->count , x + 5 + 32 , y + 100 , color ) ;
  
  vesa_print_string( "���ÿռ�: " , x + 5 , y + 120 , color ) ;
  vesa_print_string( "    " , x + 5 , y + 140 , color ) ;
  vesa_print_number( 1457664 - kernel_floppy_free_space * 512 , x + 5 + 32 , y + 140 , color ) ;
  
  vesa_print_string( "ʣ��ռ�: " , x + 5 , y + 160 , color ) ;
  vesa_print_string( "    " , x + 5 , y + 180 , color ) ;
  vesa_print_number( kernel_floppy_free_space * 512 , x + 5 + 32 , y + 180 , color ) ;
    
  // ���ļ�
  int count = 0 ;
  for( int i = kernel_start_file_number ; i < kernel_file_list->count ; ++i ){
    ++count ;
    // ת���ļ���
    int file_name_length ;
    char short_file_name[ 12 ] ;
    fat12_translate_full_file_name_to_short_file_name( kernel_file_list->full_name[ i ] , short_file_name , &file_name_length ) ;
    void *pic_address ;
    if( memory_is_equal( "BMP" , &kernel_file_list->full_name[ i ][ 8 ] , 3 ) ){
      pic_address = ( void * )0x19c000 ;
    }
    else if( memory_is_equal( "TXT" , &kernel_file_list->full_name[ i ][ 8 ] , 3 ) ){
      pic_address = ( void * )0x1a9000 ;
    }
    else{
      pic_address = ( void * )0x1a0000 ;
    }
    if( count % 2 ){
      int x_temp = x + 120 + 50 - 32 ;
      int y_temp = y + 30 + ( count - 1 ) / 2 * 100 ;
      kernel_file_list->pic_pos[ i ][ 0 ] = x_temp ;
      kernel_file_list->pic_pos[ i ][ 1 ] = y_temp ;
      vesa_show_bmp_picture( x_temp , y_temp , pic_address , 0 , 0 ) ;
      vesa_print_string( short_file_name , x + 120 + 50 - file_name_length * 8 / 2 , y + 30 + ( count -1 ) / 2 * 100 + 64 + 5 , 0 ) ; 
    }
    else{
      int x_temp = x + 120 + 100 + 25 + 50 - 32 ;
      int y_temp = y + 30 + ( count / 2 - 1 ) * 100 ;
      kernel_file_list->pic_pos[ i ][ 0 ] = x_temp ;
      kernel_file_list->pic_pos[ i ][ 1 ] = y_temp ;
      vesa_show_bmp_picture( x_temp , y_temp , pic_address , 0 , 0 ) ;
      vesa_print_string( short_file_name , x + 120 + 100 + 25 + 50 - file_name_length * 8 / 2 , y + 30 + ( count / 2 -1 ) * 100 + 64 + 5 , 0 ) ;
    }
    if( count == 6 ){
      break ;
    }
  }
  kernel_draw_file_count = count ;
 
  // ��ʾ���°�ť
  vesa_show_bmp_picture( x + 120 - 35 , y + 20 , ( void * )0x1a5000 , 0 , 0 ) ;
  vesa_show_bmp_picture( x + 120 - 35 , y + 20 + 35 , ( void * )0x1a6000 , 0 , 0 ) ;

  // ��ʾ mouse , ��Ϊ�����ڻ�����ʱ��ס�� mouse
  mouse_show_mouse( kernel_mouse_x_position , kernel_mouse_y_position , kernel_mouse_type ) ;
}

void kernel_start_picsee()
{
  picsee_x = 222 ;
  picsee_y = 50 ;

  // ���� game ��ԭͼƬ�����ƶ�ʹ��
  vesa_copy_picture_from_screen( picsee_x , picsee_y , old_picture , 356 + 32 , 372 + 32 ) ;
  kernel_kernel_state = KERNEL_OPEN_FLOPPY ;

  // ����Ϸ
  kernel_start_file_number = 0 ;
  kernel_draw_picsee( picsee_x , picsee_y ) ;  
}

// ����û���½
void kernel_login() 
{
  // ����ϵͳ��½����
  // �ð�ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_clean_screen( color ) ;  

  // ��ʾ�ڶ���ͼ������
  color = vesa_compond_rgb( 0 , 255 , 0 ) ;
  vesa_show_bmp_picture( 606 , 400 , ( void * )0x120000 , color , 1 ) ;
  
  mycomputer_picture_x = 10 ;
  mycomputer_picture_y = 10 ;

  // ����Ӧ�ó������ԭͼƬ�����ƶ�ʹ��
  vesa_copy_picture_from_screen( mycomputer_picture_x , mycomputer_picture_y , old_picture , 128 + 32 , 128 + 32 ) ; 
  
  // ��ʾӦ�ó���ͼ��
  color = vesa_compond_rgb( 0 , 255 , 0 ) ;
  vesa_show_bmp_picture( mycomputer_picture_x , mycomputer_picture_x , ( void * )0x190000 , color , 1 ) ;

  // ��ʾӢ��
  color = vesa_compond_rgb( 0 , 0 , 255 ) ;
  vesa_print_string( "PYOS MADE IN CHINA" , 630 , 552 , color ) ;
  
  // ���ױ�
  color = vesa_compond_rgb( 187 , 250 , 131 ) ;  
  for( int i = 0 ; i < 30 ; i += 2 ){
    vesa_draw_x_line( 570 + i , 0 , 799 , color ) ;
  }
  
  // ��ʾ����
  color = vesa_compond_rgb( 255 , 0 , 255 ) ;
  vesa_print_string( "�ػ�" , 4 , 577 , color ) ;
  color = vesa_compond_rgb( 0 , 0 , 255 ) ;
  vesa_print_string( "��������ҵ��ѧ л�ϲ� 2004" , 565 , 577 , color ) ;  
  
  // ��ʾ mouse
  mouse_show_mouse( 400 , 300 , MOUSE_NORMAL_MOUSE ) ;

  // �ָ� mouse ָ��
  kernel_mouse_x_position = 400 ;
  kernel_mouse_y_position = 300 ;

  // ���� mouse ״̬
  kernel_mouse_type = MOUSE_NORMAL_MOUSE ;

  // ����ϵͳ״̬
  kernel_kernel_state = KERNEL_USER_LOGED_IN ;
}

// ����½����
void kernel_draw_login_form()
{
  // �ð�ɫ����
  unsigned short color = vesa_compond_rgb( 255 , 255 , 255 ) ;
  vesa_clean_screen( color ) ;    
  
  // ���������Ϣ
  fat12_read_information( &kernel_floppy_free_space ) ;

  // ��ʾ��һ��ͼ����ռ���� ( 150 , 271 )-( 431 , 375 )
  vesa_show_bmp_picture( 150 , 271 , ( void * )0x110000 , 0 , 0 ) ;  

  // ��ʾ�ڶ���ͼ
  color = vesa_compond_rgb( 0 , 255 , 0 ) ;
  vesa_show_bmp_picture( 457 , 225 , ( void * )0x120000 , color , 1 ) ;

  // ��ʾ mouse
  mouse_show_mouse( 444 , 300 , kernel_mouse_type ) ;
}

// �ں�������
void kernel_main()
{
  // ��ʼ���ں���Ϣ����
  message_init_message_queue( &kernel_message_queue ) ;

  // ����ϵͳ��ʼ��
  system_init() ;

  // ����½����
  kernel_draw_login_form() ; 

  // ׼��������Ϣѭ��
  struct message_message_struct message ;

  // ���õ�ǰ���ں�����״̬
  kernel_kernel_state = KERNEL_WAIT_USER_LOGIN ;

  for( ;; ){
    // ȡ��һ����Ϣ
    if( !message_get_message( &kernel_message_queue , &message ) ){
      continue ;
    }
    switch( message.message_type ){
      // mouse ;
      case MESSAGE_MOUSE_MESSAGE : {
        if( kernel_kernel_state == KERNEL_WAIT_USER_LOGIN ){
          // ����Ƿ���Ҫ��½
          if( message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            kernel_login() ;
          }
          // ����Ƿ���Ҫ�ƶ� mouse
          else if( kernel_mouse_x_position != message.x_position || kernel_mouse_y_position != message.y_position ){
            // ����Ƿ���Ҫ�ı� mouse ��״
            if( vesa_does_point_in_rect( message.x_position , message.y_position , 150 , 271 , 431 , 375 ) ){
              kernel_mouse_type = MOUSE_OVER_MOUSE ;
            }
            else{
              kernel_mouse_type = MOUSE_NORMAL_MOUSE ;
            }
            mouse_move_mouse( kernel_mouse_x_position , kernel_mouse_y_position , message.x_position , message.y_position , kernel_mouse_type ) ;
            kernel_mouse_x_position = message.x_position ;
            kernel_mouse_y_position = message.y_position ;          
          }
        }
        else if( kernel_kernel_state == KERNEL_USER_LOGED_IN ){
          // ����Ƿ�Ҫ������ͼ���������ͼ��������������������������ڿ�ͼ״̬�£���Ӧ�ó���ͼ��ʧЧ
          int x_temp = message.x_position ;
          if( kernel_mouse_type == MOUSE_OVER_MOUSE ){
            x_temp += 8 ;
          }
          int ibool2 = vesa_does_point_in_rect( x_temp , message.y_position , mycomputer_picture_x , mycomputer_picture_y , mycomputer_picture_x + 128 , mycomputer_picture_y + 128 ) ;
          
          if( ibool2 && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            kernel_start_picsee() ;
          }
          
          // ����Ƿ���Ҫ�ƶ�
          // ��� x , y  ���ƶ���
          int imove_x = kernel_mouse_x_position - message.x_position ;
          int imove_y = kernel_mouse_y_position - message.y_position ;

          // ����Ƿ���Ҫ�ƶ�Ӧ�ó���ͼ��
          if( ibool2 && message.dose_right_button_down && kernel_mouse_type == MOUSE_DOWN_MOUSE && ( imove_x || imove_y ) ){
            // ��ʾҪ�ƶ�ͼ��
            // �Ȼָ�ԭͼƬ
            vesa_copy_picture_to_screen( mycomputer_picture_x , mycomputer_picture_y , old_picture , 128 + 32 , 128 + 32 ) ;
            // �ٱ���Ŀ���ַͼƬ
            vesa_copy_picture_from_screen( mycomputer_picture_x - imove_x , mycomputer_picture_y - imove_y, old_picture , 128 + 32 , 128 + 32 ) ;
            // ������λ�û���Ӧ�ó���ͼƬ
            mycomputer_picture_x -= imove_x ;
            mycomputer_picture_y -= imove_y ;
            unsigned short color = vesa_compond_rgb( 0 , 255 , 0 ) ;
            vesa_show_bmp_picture( mycomputer_picture_x , mycomputer_picture_y , ( void * )0x190000 , color , 1 ) ;
            // mouse �����滭�������ȱ��� mouse ԭλ�õ�ͼ
            mouse_save_picture( kernel_mouse_x_position , kernel_mouse_y_position ) ;
          }
          
          // ����Ƿ���Ҫ�˳�
          // ����������������ϵģ���ˣ���������Чʱ���䲻������Ч
          int ibool1 ;
          if( ibool2 ){
            ibool1 = 0 ;
          }
          else{
            ibool1 = vesa_does_point_in_rect( message.x_position , message.y_position , 4 , 570 , 38 , 593 ) ;
          }

          if( ibool1 && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            kernel_logout() ;
            break ;
          }

          // ����Ƿ���Ҫ�ı� mouse ��״
          // ���Ͽ�֪ ibool1 , ibool2 , ibool3 , ibool4 ��ͬһʱ�̣�ֻ������һ����Ч
          if( ibool1 ){
            kernel_mouse_type = MOUSE_OVER_MOUSE ;
          }
          else if( ibool2 ){
            if( message.dose_right_button_down ){
              kernel_mouse_type = MOUSE_DOWN_MOUSE ;
            }
            else{
              kernel_mouse_type = MOUSE_OVER_MOUSE ;
            }
          }
          else{
            kernel_mouse_type = MOUSE_NORMAL_MOUSE ;
          }
          
          // �ػ� mouse
          mouse_move_mouse( kernel_mouse_x_position , kernel_mouse_y_position , message.x_position , message.y_position , kernel_mouse_type ) ;
          kernel_mouse_x_position = message.x_position ;
          kernel_mouse_y_position = message.y_position ;                    
        }
        else if( kernel_kernel_state == KERNEL_OPEN_FLOPPY ){          
          int x_temp = message.x_position ;
          if( kernel_mouse_type == MOUSE_OVER_MOUSE ){
            x_temp += 8 ;
          }
          
          // ����Ƿ���up��ť��
          int ibool_up = vesa_does_point_in_rect( x_temp , message.y_position , picsee_x + 120 - 35 , picsee_y + 20 , picsee_x + 120 - 35 + 32 , picsee_y + 20 + 32 ) ;
   
          // ����Ƿ���down��ť��
          int ibool_down = vesa_does_point_in_rect( x_temp , message.y_position , picsee_x + 120 - 35 , picsee_y + 20 + 35 , picsee_x + 120 - 35 + 32 , picsee_y + 20 + 35 + 32 ) ;
          
          if( ibool_up && kernel_mouse_type == MOUSE_OVER_MOUSE && message.dose_left_button_down ){
            // ����λ�û�������ͼƬ
            kernel_start_file_number -= 2 ;
            if( kernel_start_file_number < 0 ){
              kernel_start_file_number = 0 ;
            }
            kernel_draw_picsee( picsee_x , picsee_y ) ;
          }
          else if( ibool_down && kernel_mouse_type == MOUSE_OVER_MOUSE && message.dose_left_button_down ){
            kernel_start_file_number += 2 ;
            // ����λ�û�������ͼƬ
            if( kernel_start_file_number >= kernel_file_list->count ){
              kernel_start_file_number-- ;
              if( kernel_start_file_number % 2 ){
                kernel_start_file_number-- ;
              }
            }
            kernel_draw_picsee( picsee_x , picsee_y ) ;
          }

          // ����Ƿ�Ҫ�ر���Ϸ�����������Ϸ״̬��ʧЧ
          int ibool3 = vesa_does_point_in_rect( x_temp , message.y_position ,picsee_x + 338 , picsee_y + 2 , picsee_x + 354 , picsee_y + 16 ) ;
          
          if( ibool3 && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            // �ر���Ϸ
            // �ػ�����
            kernel_login() ;
            break ;
          }

          // ����Ƿ����ļ��Ϸ�
          int ibool_file ;
          int count = 0 ;
          for( int i = kernel_start_file_number ; i < kernel_file_list->count ; ++i ){
            count++ ;
            int tmp_x = kernel_file_list->pic_pos[ i ][ 0 ] ;
            int tmp_y = kernel_file_list->pic_pos[ i ][ 1 ] ;
            ibool_file = vesa_does_point_in_rect( x_temp , message.y_position , tmp_x , tmp_y , tmp_x + 64 , tmp_y + 64 ) ;
            if( ibool_file || count == 6 ){
              break ;
            }
          }
          
          if( ibool_file && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            // ���ļ� ;
            kernel_open_file( kernel_start_file_number + count - 1 ) ;
            break ;
          }
          // ����Ƿ���Ҫ�ƶ�
          // ��� x , y  ���ƶ���
          int imove_x = kernel_mouse_x_position - message.x_position ;
          int imove_y = kernel_mouse_y_position - message.y_position ;

          // ����Ƿ���Ҫ�ƶ����������� ibool3 ��Ч����ҲʧЧ����Ϊ��ͬ ibool3 ��������
          int ibool4 ;
          if( ibool3 || ibool_up || ibool_down || ibool_file ){
            ibool4 = 0 ;
          }
          else{
            int x_temp = message.x_position ;
            if( kernel_mouse_type == MOUSE_OVER_MOUSE ){
              x_temp += 8 ;
            }
            ibool4 = vesa_does_point_in_rect( x_temp , message.y_position , picsee_x , picsee_y , picsee_x + 356  , picsee_y + 18 ) ;
          }
          if( ibool4 && kernel_mouse_type == MOUSE_DOWN_MOUSE && ( imove_x || imove_y ) ){
            // �Ȼָ�ԭͼƬ
            vesa_copy_picture_to_screen( picsee_x , picsee_y , old_picture , 356 + 32 , 372 + 32 ) ;
            // ���һ�� mouse �Ƿ��ڻָ����У�����ڣ�����������һ�����»ָ��Ķ���
            if( vesa_does_point_in_rect( kernel_mouse_x_position , kernel_mouse_y_position , picsee_x , picsee_y , picsee_x + 356 + 32 , picsee_y + 372 + 32 ) ){
              mouse_save_picture( kernel_mouse_x_position , kernel_mouse_y_position ) ;
            }
            // �ٱ���Ŀ���ַ����ͼƬ
            vesa_copy_picture_from_screen( picsee_x - imove_x , picsee_y - imove_y , old_picture , 356 + 32 , 372 + 32 ) ;
            
            // ����λ�û�������ͼƬ
            picsee_x -= imove_x ;
            picsee_y -= imove_y ;
            kernel_draw_picsee( picsee_x , picsee_y ) ;
          }

          // ����Ƿ���Ҫ�˳�
          // ����������������ϵģ���ˣ���������Чʱ���䲻������Ч
          int ibool1 ;
          if( ibool4 || ibool_up || ibool_down || ibool_file ){
            ibool1 = 0 ;
          }
          else{
            ibool1 = vesa_does_point_in_rect( message.x_position , message.y_position , 4 , 570 , 38 , 593 ) ;
          }

          if( ibool1 && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            kernel_logout() ;
            break ;
          }

          // ����Ƿ���Ҫ�ı� mouse ��״
          // ���Ͽ�֪ ibool1 , ibool2 , ibool3 , ibool4 ��ͬһʱ�̣�ֻ������һ����Ч
          if( ibool1 ){
            kernel_mouse_type = MOUSE_OVER_MOUSE ;
          }
          else if( ibool4 ){
            if( message.dose_right_button_down ){
              kernel_mouse_type = MOUSE_DOWN_MOUSE ;
            }
            else{
              kernel_mouse_type = MOUSE_NORMAL_MOUSE ;
            }
          }
          else if( ibool_up || ibool_down || ibool3 || ibool_file ){
            kernel_mouse_type = MOUSE_OVER_MOUSE ;            
          }
          else{
            kernel_mouse_type = MOUSE_NORMAL_MOUSE ;
          }
          
          // �ػ� mouse
          mouse_move_mouse( kernel_mouse_x_position , kernel_mouse_y_position , message.x_position , message.y_position , kernel_mouse_type ) ;
          kernel_mouse_x_position = message.x_position ;
          kernel_mouse_y_position = message.y_position ;    
        }
        else if( kernel_kernel_state == KERNEL_VIEW ){
          int x_temp = message.x_position ;
          if( kernel_mouse_type == MOUSE_OVER_MOUSE ){
            x_temp += 8 ;
          }
          
          // ����Ƿ���close��ť��
          int ibool_close = vesa_does_point_in_rect( x_temp , message.y_position , 50 + 70 - 50 , 20 + 530 - 105 , 50 + 2 + 100 , 20 + 530 - 105 + 100 ) ;
   
          if( ibool_close && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            // �ر��ļ�
            kernel_close_file() ;
            break ;
          }

          // ����Ƿ��ڷ���ť��
          // ����Ƿ���up��ť��
          int ibool_up =  vesa_does_point_in_rect( x_temp , message.y_position , 50 + 22 + 32 , 20 + 217 , 50 + 22 + 32 + 32 , 20 + 217 + 32 ) ;
          int ibool_down = vesa_does_point_in_rect( x_temp , message.y_position , 50 + 22 + 32 , 20 + 217 + 32 + 32 , 50 + 22 + 32 + 32, 20 + 217 + 32 + 32 + 32 ) ;
          int ibool_left = vesa_does_point_in_rect( x_temp , message.y_position , 50 + 22 , 20 + 217 + 32 , 50 + 22 + 32 , 20 + 217 + 32 + 32 ) ;
          int ibool_right = vesa_does_point_in_rect( x_temp , message.y_position , 50 + 22 + 32 + 32 , 20 + 217 +32 , 50 + 22 + 32 + 32 + 32 , 20 + 217 + 32 + 32 ) ;
          
          // ����Ƿ���down��ť��
          if( message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            if( ibool_up ){
              kernel_file_show_y_offset -= 18 ;              
            }
            else if( ibool_down ){
              kernel_file_show_y_offset += 18 ;
              if( kernel_file_show_y_offset > 0 ){
                kernel_file_show_y_offset = 0 ;
              }
            }
            else if( ibool_left ){
              kernel_file_show_x_offset -= 8 ;
            }
            else if( ibool_right ){
              kernel_file_show_x_offset += 8 ;
              if( kernel_file_show_x_offset > 0 ){
                kernel_file_show_x_offset = 0 ;
              }
            }
            kernel_show_file() ;
          }
          
          // ����Ƿ���Ҫ�˳�
          // ����������������ϵģ���ˣ���������Чʱ���䲻������Ч
          int ibool1 ;
          if( ibool_close ){
            ibool1 = 0 ;
          }
          else{
            ibool1 = vesa_does_point_in_rect( message.x_position , message.y_position , 4 , 570 , 38 , 593 ) ;
          }

          if( ibool1 && message.dose_left_button_down && kernel_mouse_type == MOUSE_OVER_MOUSE ){
            kernel_logout() ;
            break ;
          }

          // ����Ƿ���Ҫ�ı� mouse ��״
          // ���Ͽ�֪ ibool1 , ibool2 , ibool3 , ibool4 ��ͬһʱ�̣�ֻ������һ����Ч
          if( ibool1 || ibool_close || ibool_up || ibool_down || ibool_left || ibool_right ){
            kernel_mouse_type = MOUSE_OVER_MOUSE ;
          }
          else{
            kernel_mouse_type = MOUSE_NORMAL_MOUSE ;            
          }
          
          // �ػ� mouse
          mouse_move_mouse( kernel_mouse_x_position , kernel_mouse_y_position , message.x_position , message.y_position , kernel_mouse_type ) ;
          kernel_mouse_x_position = message.x_position ;
          kernel_mouse_y_position = message.y_position ;   
        }       
        break ;
      }
      case MESSAGE_SHUTDOWN_COMPUTER : {
        break ; 
      }
    }    
  }
  // ͣ��
  for( ;; ){
    __asm__( "hlt" ) ;
  }
}
