/////////////////////////////////////////////////////////////////////////////
// Name:        console_boxman.cpp
// Purpose:     Provide a CUI for the game(windows only)
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/25
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "../Base/BoxRoom.h"
#include "../Base/prog_info.h"
#include "../SolveBoxRoom/SolveBoxRoom.h"
#include <map>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <boost/timer.hpp>
#include <conio.h>
using namespace std;
USING_NAMESPACE_BOXMAN

static  map<Element,char*> Element2CString;
char*   Direction2char[] = {"��","��","��","��"};

void PrintMovePath(ostream& os, const MovePath& mypath){
    for(size_t i = 0; i < mypath.size(); ++i)
        os << Direction2char[mypath[i]];
}

void ShowRoom(BoxRoom& room){
    system("cls");
    cout << "H����ʾ����" << endl;
    cout << "  ";
    for(int i = 0; i < room.GetCol(); ++i)cout << setw(2) << setfill('0') <<  i;
    cout << endl;
    for(int y = 0; y < room.GetRow(); ++y){
        cout << setw(2) << setfill('0') << y;
        for(int x = 0; x < room.GetCol(); ++x){
            if(room.xy_position(x,y) == room.GetManPosition())cout << "��";
            else cout << Element2CString[room.GetItem(x,y)];
        }
        cout << endl; 
    }
    cout << "�Ѿ��߹��Ĳ���:\t" << room.GetTotlestep() << endl;
    if(IsBoxRoomDead(room))cout << "������Ѿ���ס�ˣ�" << endl;
}

int main(){
    cout << "\t" << prog_name << endl;
    cout << box_man_about << endl;
    getch();
    Element2CString[EM_NONE]           = "��";
    Element2CString[EM_BOX]            = "��";
    Element2CString[EM_FLOOR]          = "��";
    Element2CString[EM_FLOOR_TARGET]   = "��";
    Element2CString[EM_WALL]           = "��";
    Element2CString[EM_BOX_TARGET]     = "��";
    BoxRoom room;
begin:
    system("cls");
    bool    successload = false;
    do{
        string  round;
        cout << "ѡ��ؿ�(Ĭ��·��:\t../STAGES/NOAH/)��";getline(cin,round);
        if(round == "quit")return 0;
        round = "../STAGES/NOAH/" + round;
        switch(room.LoadFile(round)){
            case FLAG_LOAD_FILE_NOTEXST:
                cerr << "�ؿ�������:-(\n";break;
            case FLAG_LOAD_FILE_DATAERR:
                cerr << "�ؿ����ݳ���:-(\n";break;
            case FLAG_LOAD_FILE_SUCCESS:
                cerr << "����ɹ�:-)\n";successload = true;break;
            default:
                cerr << "δ֪����!\n";
        }
    }while(!successload);
    BoxRoom::BoxRoomState   startstate;
    room.SaveState(startstate);
    do{
        ShowRoom(room);
        int c = getch();
        if(c == 'q' || c == 'Q')break;
        if(c == 'r' || c == 'R'){room.LoadState(startstate);continue;}
        if(c == 'c' || c == 'C'){goto begin;}
        if(c == 'h' || c == 'H'){
            cout << 
                "�������Ҽ��ƶ����˹����ҿ���������\n"
                "�����кţ������ּ����кţ��ƶ����ض��㣨������С��\n"
                "R������\n"
                "C������ͼ\n"
                "S���Զ����\n"
                "Q���˳�\n";
            getch();
        }
        if(c == 's' || c == 'S'){
            SolveResult    path;
            cout << "������⣬�����ĵȴ�����" << endl;
            boost::timer time;
            if(SolveBoxRoom(room,path) == -1){
                cout << "֤���޽⣡" << endl;
                getch();
            }
            stringstream ss;
            for(int i = 0; i < (int)path.size(); ++i){
                MovePath         movepath;
                room.Goto(path[i].p,movepath);
                PrintMovePath(ss,movepath);
                room.MovePush(path[i].d);
                ss << Direction2char[path[i].d];
            }
            ShowRoom(room);
            cout << "\n������,�ܹ���ʱ:" << time.elapsed() << endl; 
            cout << "���·�ߣ�" << ss.str() << endl;
            getch();
            continue;
        }
        if(isdigit(c)){
            int x = c - 0x30;
            cout << "X:";
            putch(c);
            while(isdigit(c = getch())){
                putch(c);
                x = x*10 + c - 0x30;
            }
            cout << "\tY:";
            if(!isdigit(c = getch()))continue;
            putch(c);
            int y = c - 0x30;
            while(isdigit(c = getch())){
                putch(c);
                y = y*10 + c - 0x30;
            }
            cout << endl;
            MovePath    mypath;
            room.Goto(x,y,mypath);
            cout << "·������:" << (int)mypath.size() << endl;
            PrintMovePath(cout, mypath);
            cout << endl;
            getch();
            continue;
        }
        if(c == 0xE0){
            c = getch();
            switch(c){
                case 0x48:
                    room.MovePush(NORTH);break;
                case 0x4b:
                    room.MovePush(WEST);break;
                case 0x4d:
                    room.MovePush(EAST);break;
                case 0x50:
                    room.MovePush(SOUTH);break;
            }
        }
    }while(!room.IsFinished());
    ShowRoom(room);
    if(room.IsFinished()){
do_u_want_continue:
        cout << "�Ƿ���������٣��Σ�";
        switch(int c = getch()){
            case 'y':case 'Y':goto begin;
            case 'n':case 'N':break;
            default:
                cout << endl;
                goto do_u_want_continue;
                cout << "�ҿ�!����Ϊ����SB�ء���" << endl;
        }
    }else cout << "���˰ɣ���Ȼ��SB!����" << endl;
}

