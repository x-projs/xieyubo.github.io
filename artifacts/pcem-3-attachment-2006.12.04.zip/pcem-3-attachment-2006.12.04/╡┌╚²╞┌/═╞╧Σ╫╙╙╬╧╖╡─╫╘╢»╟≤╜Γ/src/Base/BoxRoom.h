/////////////////////////////////////////////////////////////////////////////
// Name:        BoxRoom.h
// Purpose:     Provide facility for the GAME
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/25
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#ifndef BOXROOM_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6
#define BOXROOM_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6


// ---------------------------------------------------------------------------
// some macros
// ---------------------------------------------------------------------------
#define BEGIN_BOXMAN_NAMESPACE  namespace BoxMan{
#define END_BOXMAN_NAMESPACE    };
#define USING_NAMESPACE_BOXMAN  using namespace BoxMan;

// ---------------------------------------------------------------------------
// headers
// ---------------------------------------------------------------------------
#include <vector>
#include <deque>
#include <string>
#include <algorithm>    //count
#include <boost/dynamic_bitset.hpp>

BEGIN_BOXMAN_NAMESPACE
// ===========================================================================
// Declarations
// ===========================================================================
using   std::vector;
using   std::string;
using   std::deque;

typedef unsigned char               Element;
typedef         short               Position;

enum    Direction{
    EAST = 0,                   SOUTH = 1,
    WEST = 3 - EAST/* == 3 */,  NORTH = 3 - SOUTH/* == 2 */
};
inline  
int REVERSE_DIRECTION(int d){return    static_cast<Direction>(3-d);}
typedef     deque<Direction>     MovePath;

const int FLAG_LOAD_FILE_SUCCESS = 0;
const int FLAG_LOAD_FILE_NOTEXST = 1;
const int FLAG_LOAD_FILE_DATAERR = 2;



// ===========================================================================
// Constants
// ===========================================================================
const   Element             TARGET_BIT      = 0x40;                //0100 0000
const   Element             EM_NONE         = 0x00;                //0000 0000
const   Element             EM_WALL         = 0x01;                //0000 0001
const   Element             EM_BOX          = 0x02;                //0000 0010
const   Element             EM_FLOOR        = 0x04;                //0000 0100
const   Element             EM_BOX_TARGET   = EM_BOX  | TARGET_BIT;//0100 0010
const   Element             EM_FLOOR_TARGET = EM_FLOOR| TARGET_BIT;//0100 0100



// ===========================================================================
// Main Section
// ===========================================================================
class BoxRoom{
protected:
    vector<Element> m_map;          //��ͼ����
    Position        m_manpos;       //�˵�λ��
    short           m_row,m_col;    //��ͼ���к���
    short           m_totlestep;    //���Ѿ��߹��ľ���
    short           m_size;         //aux m_map, == m_row*m_col
    short           m_nbox;         //aux m_map, ���ӵ���Ŀ
    short           m_dir_offset[4];//aux m_map, ÿ����������Ӧ��λ�õ�ƫ����


    //���ݹ�����صĺ���
    //������BoxRoom_build.cpp�ж���
private:
    void    sync_aux_data(){
        m_dir_offset[WEST] = -1;
        m_dir_offset[EAST] =  1;
        m_dir_offset[NORTH]= -m_col;
        m_dir_offset[SOUTH]=  m_col;

        m_size = m_row*m_col;

        m_nbox = 0;
        for(unsigned int i = 0; i < m_map.size(); ++i)
            if(IsBox(i))++m_nbox;
    }
public:
    BoxRoom():m_map(1,EM_FLOOR){
        m_manpos=0;
        m_row=m_col=1;
        m_totlestep=0;
        sync_aux_data();
    }
    //��vector�л�ȡ���ݣ�������������ԣ�
    void    SetData(const vector<Element>&, short r, short c, Position m);
    int     LoadFile(const string& filename);


    //���ݵĻ�ȡ(const ��Ա����)
public:
    inline  Element GetItem(Position n)const{return m_map[n];}
    inline  Element GetItem(Position x,Position y)const{return GetItem(xy_position(x,y));}
    inline  short   GetManPosition()const{return m_manpos;}
    inline  short   GetManPositionX()const{return position_x(m_manpos);}
    inline  short   GetManPositionY()const{return position_y(m_manpos);}
    inline  short   GetRow()const{return m_row;}
    inline  short   GetCol()const{return m_col;}
    inline  short   GetSize()const{return m_size;}
    inline  short   GetTotlestep()const{return m_totlestep;}
    inline  short   GetNumberOfBoxes()const{return m_nbox;}
    inline  short   GetOffset(Direction d)const{return m_dir_offset[d];}
    inline  short   IsFloor(Position p)const{return (m_map[p] & EM_FLOOR);}
    inline  short   IsNotFloor(Position p)const{return !IsFloor(p);}
    inline  short   IsBox(Position p)const{return (m_map[p] & EM_BOX);}
    inline  short   IsNotBox(Position p)const{return !IsBox(p);}
    bool            IsFinished()const{
        return m_nbox && m_nbox == std::count(m_map.begin(),m_map.end(),EM_BOX_TARGET);
    }


    //���ݵĲ���(�˵��ƶ�,����GotoDistance��GetPath��
    //����ֵ:-1��ʾʧ��,����Ϊ����Ҫ�ƶ��Ĳ���
    //������BoxRoom_Goto.cpp�ж���
public:
    //�ƶ�һ��,��������Ӿ���
    short           MovePush(Direction);
    //Goto�������ƶ���һ��,�����ܷ���һ���ƶ���·��
    short           Goto(Position p);
    inline short    Goto(Position x, Position y){return Goto(xy_position(x,y));}
    short           Goto(Position p, MovePath& path);
    inline short    Goto(Position x, Position y, MovePath& path){return Goto(xy_position(x,y),path);}
    short           GetPath(Position p, MovePath& path)const;
    short           GetPath(Position x, Position y, MovePath& path)const{return GetPath(xy_position(x,y),path);};
    //�����˵�ĳһ�����С����
    short           GotoDistance(Position p)const;


    //��λ���йص�һ�鹤�ߺ���
public:
    //һάPosition <=> ��άPosition
    inline  Position    position_x(Position p)const{return p%m_col;}
    inline  Position    position_y(Position p)const{return p/m_col;}
    inline  Position    xy_position(Position x,Position y)const{return y*m_col+x;}
    //�ж�λ�õ�ֵ�Ƿ���Ч
    inline  bool        is_not_valid_position(Position p)const{return (p < 0 || p >= m_size);}
    inline  bool        is_valid_position(Position p)const{return !is_not_valid_position(p);}
    //�ж�����λ���Ƿ���ͼ������
    inline  bool        is_not_adjacent_position(Position i, Position j)const{
        return (position_x(i) != position_x(j) && position_y(i) != position_y(j));
    }
    inline  bool        is_adjacent_position(Position i, Position j)const{
        return !is_not_adjacent_position(i,j);
    }
    //�ж�����λ�ü�������پ���
    inline  short       manhattan_distance(Position i, Position j)const{
        return abs(position_x(i) - position_x(j)) + abs(position_y(i) - position_y(j));
    }

    //״̬�ı���������
public:
    //BoxRoomSnapShot����������������Ϣ
    //BoxRoomState���������ض����������,���ҿ����޸�m_totlestep
    //���߸���ʡ�ռ�
    class   BoxRoomSnapShot{
        friend  class   BoxRoom;

        vector<Element> m_map;          //��ͼ����
        Position        m_manpos;       //�˵�λ��
        short           m_row,m_col;    //��ͼ���к���
        short           m_totlestep;    //���Ѿ��߹��ľ���
    };
    void    SaveSnapShot(BoxRoomSnapShot& s)const{
        s.m_map         = m_map;
        s.m_manpos      = m_manpos;
        s.m_row         = m_row;
        s.m_col         = m_col;
        s.m_totlestep   = m_totlestep;
    }
    void    LoadSnapShot(const BoxRoomSnapShot& s){
        m_map         = s.m_map;
        m_manpos      = s.m_manpos;
        m_row         = s.m_row;
        m_col         = s.m_col;
        m_totlestep   = s.m_totlestep;
        sync_aux_data();
    }

    class   BoxRoomState{
        friend  class   BoxRoom;
        boost::dynamic_bitset<> m_extracted_map;
        Position                m_manpos;
        short                   m_totlestep;
        //�Ƚ�״̬�Ƿ�ȼ�
        //�ȼۣ����״̬A���ܹ������ӱ��ֲ���������´ﵽ״̬״̬B����ôA<=>B
        //���ʣ��Է��ԣ������ԣ��Գ���
        //
        //ע�⣺���Ҫ�����Ƚ��ѱ�ʾ������������ʱֻ������������!�����ϸ��˵���ﲻ����==�Ķ���
    public:
        bool        operator==(const BoxRoomState& oth)const{
            return m_manpos  == oth.m_manpos && m_extracted_map == oth.m_extracted_map;
        }
        inline int  GetTotlestep()const{return m_totlestep;}
        inline void SetTotlestep(int s){m_totlestep = s;}
    };
    void    SaveState(BoxRoomState& s)const{
        s.m_extracted_map.resize(m_size);
        for(int i = 0;i < m_size; ++i){
            if(IsBox(i)){
                s.m_extracted_map[i] = 1;
            }else{
                s.m_extracted_map[i] = 0;
            }
        }
        s.m_totlestep   = m_totlestep;
        s.m_manpos      = m_manpos;
    }
    void    LoadState(const BoxRoomState& s){
        m_manpos    =   s.m_manpos;
        m_totlestep =   s.m_totlestep;
        for(int i = 0;i < m_size; ++i){
            if(s.m_extracted_map[i]){
                m_map[i]    = EM_BOX    | (m_map[i] & TARGET_BIT);
            }else{
                if(IsBox(i))m_map[i] = EM_FLOOR  | (m_map[i] & TARGET_BIT);
            }
        }
    }
};

END_BOXMAN_NAMESPACE
#endif
