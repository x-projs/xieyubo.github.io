/////////////////////////////////////////////////////////////////////////////
// Name:        prog_info.h
// Purpose:     infomation for the programme
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/25
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#ifndef PROG_INFO_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6
#define PROG_INFO_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6

extern  char*   prog_name;
extern  char*   box_man_about;

#endif
