/////////////////////////////////////////////////////////////////////////////
// Name:        BoxRoom_build.h
// Purpose:     One of BoxRoom's implemented files
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/25
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "BoxRoom.h"
#include <fstream>

USING_NAMESPACE_BOXMAN

//��vector�л�ȡ���ݣ�������������ԣ�
void    BoxRoom::SetData(const vector<Element>& e, short r, short c, Position m){
    m_manpos    = m;
    m_row       = r; 
    m_col       = c;
    m_totlestep = 0;
    m_map.resize(r*c);
    for(int i = 0; i < m_row; ++i)
        for(int j = 0; j < m_col; ++j)m_map[xy_position(j,i)] = e[xy_position(j,i)];
    for(int i = 0; i < m_row; ++i){
        int j1 = 0, j2 = m_col - 1;
        while(m_map[xy_position(j1,i)] == EM_FLOOR){
            m_map[xy_position(j1,i)] = EM_NONE;
            j1++;
        }
        while(m_map[xy_position(j2,i)] == EM_FLOOR){
            m_map[xy_position(j2,i)] = EM_NONE;
            j2--;
        }
    }
    for(int j = 0; j < m_col; ++j){
        int i1 = 0, i2 = m_row - 1;
        while(e[xy_position(j,i1)] == EM_FLOOR){
            m_map[xy_position(j,i1)] = EM_NONE;
            i1++;
        }
        while(e[xy_position(j,i2)] == EM_FLOOR){
            m_map[xy_position(j,i2)] = EM_NONE;
            i2--;
        }
    }
    sync_aux_data();
}

int BoxRoom::LoadFile(const string& filename){
    /*
    *
    *ÿһ�д����ֿ��һ�У������п��С�
    *�ո��='��ʾ�ذ塣ÿ����������ĵذ����ʡ�ԡ�
    *��#����ʾǽ��
    *��@����ʾ�ˡ�
    *��$����ʾ���ӡ�
    *��.����ʾĿ�ĵ㡣
    *��*����ʾ��Ŀ�ĵ��ϵ����ӡ�
    *��+����%����ʾ��Ŀ�ĵ��ϵ��ˡ�
    *
    */
    try{
        short r(0),c(0),x(0),y(0);
        vector<string>  strs;
        std::ifstream file(filename.c_str());
        if(!file){return FLAG_LOAD_FILE_NOTEXST;}
        while(file){
            strs.push_back(string());
            std::getline(file,strs.back());
            c = std::max((short)strs.back().size(),c);
            if(strs.back() == "REM")break;
            if(strs.back().size() > 0)++r;
        }
        vector<Element>    data(r*c,-1);
        for(int i = 0; i < r; ++i){
            const   string& str = strs[i];
            for(int j = 0; j < (int)str.size(); ++j){
                int p = i*c + j;
                char cc = str[j];
                switch(cc){
                    case '$':
                        data[p] = EM_BOX;break;
                    case ' ':
                        data[p] = EM_FLOOR;break;
                    case '.':
                        data[p] = EM_FLOOR_TARGET;break;
                    case '#':
                        data[p] = EM_WALL;break;
                    case '*':
                        data[p] = EM_BOX_TARGET;break;
                    case '+':
                        data[p] = EM_FLOOR_TARGET;
                        x = (p)%c;
                        y = (p)/c;
                        break;
                    case '@':
                        data[p] = EM_FLOOR;
                        x = (p)%c;
                        y = (p)/c;
                        break;
                    default:
                        return FLAG_LOAD_FILE_DATAERR;
                }
            }
            for(int j = (int)str.size(); j < c; ++j)data[i*c + j] = EM_FLOOR;
        };
        SetData(data,r,c,y*c+x);
    }catch(...){
        return FLAG_LOAD_FILE_DATAERR;
    }
    return FLAG_LOAD_FILE_SUCCESS;
}
