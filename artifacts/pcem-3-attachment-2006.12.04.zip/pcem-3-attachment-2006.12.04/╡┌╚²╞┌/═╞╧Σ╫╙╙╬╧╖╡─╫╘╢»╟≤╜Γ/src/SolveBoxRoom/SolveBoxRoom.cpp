/////////////////////////////////////////////////////////////////////////////
// Name:        SolveBoxRoom.cpp
// Purpose:     Implement file for the solve algorith
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/26
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "SolveBoxRoom.h"
#include <vector>
using std::vector;

#define HASH_RANK           16
#define HASH_SIZE(rank)     (1 << rank)
#define HASH_MOD(hash)      (hash & ( (1 << HASH_RANK) - 1))

BEGIN_BOXMAN_NAMESPACE

struct SolveState{
    BoxRoom::BoxRoomState       roomstate;
    int                         hash;
    int                         depth;
    int                         depthindex;
    bool                        isfinished;
    ValidStep                   laststep;
    SolveState(const BoxRoom& room);
    bool    operator == (const SolveState& oth)const{
        return  hash == oth.hash && roomstate == oth.roomstate;
    }
    inline int  GetTotlestep()const{ return roomstate.GetTotlestep(); }
    inline void SetTotlestep(int s){ roomstate.SetTotlestep(s); }
};

SolveState::SolveState(const BoxRoom& room):hash(0){
    room.SaveState(roomstate);
    isfinished = room.IsFinished();
    //��hashֵ
    for(int i = 0;i < room.GetSize(); ++i){
        if(room.IsBox(i)){
            hash += i*(i+1)*(i+2);
            hash = HASH_MOD(hash);
        }
    }
}

class SolveSearchTree{
    class StateLib{
        typedef vector<SolveState>  HashNode;
        vector<HashNode>            m_hash_table;
    public:
        StateLib(int rank):m_hash_table(HASH_SIZE(rank)){}
        int Add_state(const SolveState& ns){
            HashNode&           data = m_hash_table[ns.hash];
            HashNode::iterator  iter = find(data.begin(),data.end(),ns);
            long h1;
            if( iter == data.end() ){
                data.push_back(ns);
                h1 = (long)data.size() - 1;
                return (h1<< HASH_RANK)+ns.hash;
            }else{
                if(ns.GetTotlestep() < (*iter).GetTotlestep()){
                    h1 = (long)(iter - data.begin());
                    (*iter).SetTotlestep(ns.GetTotlestep());
                    (*iter).laststep = ns.laststep;
                    return -((h1<< HASH_RANK)+ns.hash);
                }
                //Magic Number,��ʾ�޷����������״̬,��Ϊ�Ѿ����ڲ������ŵĵȼ�״̬
                //��Ϊhash!=0,����˵�����(h1<< HASH_RANK)+ns.GetHash()�϶��������0
                return 0;
            }
        }

        SolveState& Get_state(int stateindex){
            HashNode& data = m_hash_table[HASH_MOD(stateindex)];
            return data[stateindex >> HASH_RANK];
        }
    }statelib;

    struct  Node{
        int                 stateindex;//״̬��StateLib�е�����ֵ
        vector<int>         children;  //���к�������һ�������е�index�Ľڵ��
        int                 fatherindex;
        bool                is_expanded;
        bool                is_disabled;
        Node():is_expanded(false),is_disabled(false){}
    };

    //�����ڹ�����ķ�ʽ��Ϊ���ı�ʾ��ʽ��data[n]�������ĵ�n�㣬data[n][m]������n��ĵ�m����Ա
    vector<vector<Node> >   data;
    SolveState              dummystate;

public:
    SolveSearchTree(SolveState& r);
    void            insert(int fatherdepth ,int fatherindex, SolveState&);
    void            getnextchild(int fatherdepth, int fatherindex, int& lastchildindex, SolveState&);
    void            getfather(int childepth, int childindex, SolveState&);
    bool            have_not_been_expanded(int depth,int index)const{return !(data[depth][index].is_expanded);}
    void            set_expanded(int depth,int index){data[depth][index].is_expanded = true;}
    bool            have_not_been_disabled(int depth,int index)const{return !(data[depth][index].is_disabled);}
    void            set_disabled(int depth,int index){
        data[depth][index].is_disabled = true;
        data[depth][index].children.clear();
    }
};

SolveSearchTree::SolveSearchTree(SolveState& r):dummystate(r),statelib(HASH_RANK){
    data.push_back(vector<Node>());
    data[0].push_back(Node());
    r.depth = 0; r.depthindex = 0;
    data[0][0].stateindex = statelib.Add_state(r);
}

void    SolveSearchTree::insert(int fatherdepth ,int fatherindex,SolveState& ss){
    int newchildstateindex = statelib.Add_state(ss);
    if(newchildstateindex == 0)return;
    if(newchildstateindex < 0){
        newchildstateindex = -newchildstateindex;
        SolveState& ts = statelib.Get_state(newchildstateindex);
        set_disabled(ts.depth,ts.depthindex);
    }
    if((int)data.size() <= fatherdepth + 1)data.push_back(vector<Node>());
    Node childnode;
    childnode.stateindex = newchildstateindex;
    childnode.fatherindex = fatherindex;
    data[fatherdepth+1].push_back(childnode);
    int newchilddepthindex = (int)data[fatherdepth+1].size() - 1;

    SolveState& ts = statelib.Get_state(newchildstateindex);
    ts.depth        = fatherdepth + 1;
    ts.depthindex   = newchilddepthindex;
    data[fatherdepth][fatherindex].children.push_back(newchilddepthindex);
}

void    SolveSearchTree::getnextchild(int fatherdepth, int fatherindex, int& lastchildindex, SolveState& rt){
    vector<int>&            childindex = data[fatherdepth][fatherindex].children;
    vector<int>::iterator   iter;
    if(lastchildindex == -1){
        iter = childindex.begin();
    }else{
        iter = find(childindex.begin(),childindex.end(),lastchildindex) + 1;
    }
    do{
        if(iter == childindex.end()){
            lastchildindex = -1;
            rt = dummystate;return;
        }else{
            lastchildindex = *iter;
            if(data[fatherdepth+1][lastchildindex].is_disabled){
                ++iter;
                continue;
            }
            rt = statelib.Get_state(data[fatherdepth+1][lastchildindex].stateindex);return;
        }
    }while(true);
}

void    SolveSearchTree::getfather(int childepth, int childindex, SolveState& rt){
    rt =statelib.Get_state(
        data[childepth - 1][
            data[childepth][childindex].fatherindex
        ].stateindex
        );
}

int SolveBoxRoom(BoxRoom room, SolveResult& path){
    //�����״̬
    SolveState      startstate(room);
    SolveSearchTree searchtree(startstate);
    int     limit= room.GetTotlestep();
    bool    no_solution;
    do{
        SolveState  curstate = startstate;
        int         curdepth = -1;
        //����ÿһ���Ѿ��������Ľڵ��index
        vector<int> indexlist(1,0);
        no_solution = true;
        limit++;
        do{
            ++curdepth;
            //һ��ʼ��״̬��û��չ��
            if(curdepth != 0){
                //��һ����������һ�㣬��indexlist[curdepth] = -1
                if((int)indexlist.size() <= curdepth)indexlist.push_back(-1);
                searchtree.getnextchild(curdepth - 1, indexlist[curdepth-1],indexlist[curdepth],curstate);
                //��һ���Ѿ��޷��õ����õĽڵ���
                if(indexlist[curdepth] == -1){
                    //�Ѿ���ͷ��
                    if(curdepth <= 1)break;
                    //ʲô��ʲô��û����������һ֧
                    if(no_solution)
                        searchtree.set_disabled(curdepth - 1,indexlist[curdepth - 1]);
                    //û�е�ͷ,���ϻ�˷
                    curdepth-=2;continue;
                }
            }

            //�Ѿ�������ȵ�����,��ͬһ��ȵ������ڵ�
            if(limit < curstate.roomstate.GetTotlestep()){
                no_solution = false;
                --curdepth;continue;
            }
            room.LoadState(curstate.roomstate);

            if(curstate.isfinished){
                SolveResult result;
                for(int i = curdepth; i > 0;  i = curstate.depth){
                    result.push_back(curstate.laststep);
                    searchtree.getfather(curstate.depth,curstate.depthindex,curstate);
                }
                path.insert(path.end(),result.rbegin(),result.rend());
                return room.GetTotlestep();
            }
            //չ��һ���ڵ㣬�����û��չ����
            if( searchtree.have_not_been_expanded(curdepth,indexlist[curdepth])){
                //չ������ڵ�
                BoxRoom::BoxRoomSnapShot  tmpstate;
                room.SaveSnapShot(tmpstate);
                for(Position i = 0; i < room.GetSize(); ++i){
                    if(room.IsNotBox(i))continue;
                    for(int j = 0; j < 4; ++j){
                        Position nman = i - room.GetOffset(static_cast<Direction>(j));
                        if(room.Goto(nman) != -1){
                            if((room.MovePush(static_cast<Direction>(j)) != -1)
                                && !IsBoxRoomDead(room)){
                                    SolveState  ss(room);
                                    ss.laststep = ValidStep(nman,static_cast<Direction>(j));
                                    searchtree.insert(curdepth,indexlist[curdepth],ss);
                                }
                                room.LoadSnapShot(tmpstate);
                        }
                    }
                }
                searchtree.set_expanded(curdepth,indexlist[curdepth]);
                no_solution = false;
            }
        }while(true);
    }while(!no_solution);
    return  -1;
}

END_BOXMAN_NAMESPACE
