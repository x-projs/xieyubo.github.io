/////////////////////////////////////////////////////////////////////////////
// Name:        SolveBoxRoom.h
// Purpose:     Solve the game by Computer
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/26
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#ifndef SOLVEBOXROOM_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6
#define SOLVEBOXROOM_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6

#include "../Base/BoxRoom.h"

BEGIN_BOXMAN_NAMESPACE

enum    SOLVE_MODE{BEST_MOVE,BEST_PUSH,JUST_ONE_RESULT};//to..do..*_*

//��ʾ���е�һ����Ч�ƶ�:��ʾ�ߵ�һ��������,���ƶ���
struct  ValidStep{
    Position            p;
    Direction           d;
    ValidStep():p(-1),d(EAST){}
    ValidStep(int pp, Direction dd):p(pp),d(dd){}
};

typedef vector<ValidStep> SolveResult;

int     SolveBoxRoom(BoxRoom, SolveResult&);
bool    IsBoxRoomDead(BoxRoom& room);
int     BoxRoomMinStep(const BoxRoom&);

END_BOXMAN_NAMESPACE

#endif
