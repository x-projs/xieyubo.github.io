/////////////////////////////////////////////////////////////////////////////
// Name:        IsBoxRoomDead.cpp
// Purpose:     Exam whether the game is doomed to over.
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/26
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "SolveBoxRoom.h"

BEGIN_BOXMAN_NAMESPACE

bool    IsBoxRoomDead(BoxRoom& room){
    //����һ�����ӻ���ǽ��������������λ��������������
    /*
     * #B #   # B# ## #B B# BB BB BB
     * #  B# #B #  BB #B B# ## BB BB
    */
    {
        for(int y = 0; y < room.GetRow() - 1; ++y)
            for(int x = 0; x < room.GetCol() - 1; ++x){
                //BB
                //BB
                if(room.GetItem(x ,y )  == EM_BOX &&
                    room.GetItem(x+1,y ) == EM_BOX &&
                    room.GetItem(x ,y+1) == EM_BOX &&
                    room.GetItem(x+1,y+1) == EM_BOX )return true;
                if(room.GetItem(x ,y ) == EM_WALL ){
                    //#B #  ## #B
                    // # B# BB #B
                    if(room.GetItem(x+1,y+1) == EM_BOX){
                        //## #B
                        //BB #B
                        if( (room.GetItem(x+1,y ) == EM_BOX  && room.GetItem(x ,y+1) == EM_WALL) ||
                            (room.GetItem(x+1,y ) == EM_WALL && room.GetItem(x ,y+1) == EM_BOX)
                            )return true;
                    }else if(room.GetItem(x+1,y+1) == EM_WALL){
                        //#  #B
                        //B#  #
                        if((room.GetItem(x+1,y ) == EM_BOX || room.GetItem(x ,y+1) == EM_BOX))return true;
                    }
                }else if(room.GetItem(x ,y ) == EM_BOX){
                    //B# B# BB 
                    //#  B# ##
                    if(room.GetItem(x+1,y ) == EM_WALL){
                        //B# B#
                        //#  B#
                        if( (room.GetItem(x ,y+1) == EM_WALL) ||
                            (room.GetItem(x ,y+1) == EM_BOX && room.GetItem(x+1,y+1) == EM_WALL))return true;
                    }else if(room.GetItem(x+1,y ) == EM_BOX && 
                        room.GetItem(x ,y+1) == EM_WALL &&
                        room.GetItem(x+1,y+1) == EM_WALL)return true;
                }
                // #
                //#B
                else if(room.GetItem(x+1,y ) == EM_WALL && 
                    room.GetItem(x ,y+1) == EM_WALL &&
                    room.GetItem(x+1,y+1) == EM_BOX)return true;
            }
    }
    //�������
    {
        bool    skip = false;
        int     b = 0, t  = 0, d = 0;
        //���ϵ���
        for(int y = 1; y < room.GetRow(); ++y){
            int x = 0;
            while(room.GetItem(x,y) == EM_FLOOR)++x;
            for(; x < room.GetCol(); ++x){
                switch(room.GetItem(x,y)){
                    case    EM_BOX:b++;break;
                    case    EM_FLOOR_TARGET:t++;break;
                    case    EM_WALL:
                        if(d == 0 && b > t)return true;
                        skip = true;
                }
                if(skip){skip=false;continue;}
                switch(room.GetItem(x,y-1)){
                    case EM_BOX_TARGET: case EM_BOX:case    EM_FLOOR:case EM_FLOOR_TARGET:d++;
                }
            }
            if( d == 0 && b > t)return true;
            b = d = t = 0;
        }
        //������
        b = 0, t  = 0, d = 0;
        for(int x = 1; x < room.GetCol(); ++x){
            int y = 0;
            while(room.GetItem(x,y) == EM_FLOOR)++y;
            for(; y < room.GetRow(); ++y){
                switch(room.GetItem(x,y)){
                    case    EM_BOX:b++;break;
                    case    EM_FLOOR_TARGET:t++;break;
                    case    EM_WALL:
                        if(d == 0 && b > t)return true;
                        skip = true;
                }
                if(skip){skip=false;continue;}
                switch(room.GetItem(x - 1,y)){
                    case EM_BOX_TARGET: case EM_BOX:case    EM_FLOOR:case EM_FLOOR_TARGET:d++;
                }
            }
            if( d == 0 && b > t)return true;
            b = d = t = 0;
        }
        //���µ���
        b = 0, t  = 0, d = 0;
        for(int y = room.GetRow() - 1; y > 0; --y){
            int x = 0;
            while(room.GetItem(x,y) == EM_FLOOR)++x;
            for(; x < room.GetCol(); ++x){
                switch(room.GetItem(x,y-1)){
                    case    EM_BOX:b++;break;
                    case    EM_FLOOR_TARGET:t++;break;
                    case    EM_WALL:
                        if(d == 0 && b > t)return true;
                        skip = true;
                }
                if(skip){skip=false;continue;}
                switch(room.GetItem(x,y)){
                    case EM_BOX_TARGET: case EM_BOX:case    EM_FLOOR:case EM_FLOOR_TARGET:d++;

                }
            }
            if( d == 0 && b > t)return true;
            b = d = t = 0;
        }
        //���ҵ���
        b = 0, t  = 0, d = 0;
        for(int x = room.GetCol() - 1; x > 0; --x){
            int y = 0;
            while(room.GetItem(x,y) == EM_FLOOR)++y;
            for(; y < room.GetRow(); ++y){
                switch(room.GetItem(x - 1,y)){
                    case    EM_BOX:b++;break;
                    case    EM_FLOOR_TARGET:t++;break;
                    case    EM_WALL:
                        if(d == 0 && b > t)return true;
                        skip = true;
                }
                if(skip){skip=false;continue;}
                switch(room.GetItem(x,y)){
                    case EM_BOX_TARGET: case EM_BOX:case    EM_FLOOR:case EM_FLOOR_TARGET:d++;
                }
            }
            if( d == 0 && b > t)return true;
            b = d = t = 0;
        }
    }
    return false;
}

END_BOXMAN_NAMESPACE
