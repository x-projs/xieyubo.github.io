/////////////////////////////////////////////////////////////////////////////
// Name:        BoxRoomMinStep.cpp
// Purpose:     How many steps at least to solve the ROOM.(Unused now)
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/26
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "SolveBoxRoom.h"
#include <limits>
#include <algorithm>    //max min next_permutation


BEGIN_BOXMAN_NAMESPACE

int BoxRoomMinStep(const BoxRoom& room){
    //h1
    vector<Position>    boxes,target;
    for(int i = 0; i < int(room.GetSize()); ++i){
        switch(room.GetItem(i)){
            case EM_BOX:
                boxes.push_back(i);
                break;
            case EM_FLOOR_TARGET:
                target.push_back(i);
                break;
        }
    }
    int _size = (int)boxes.size();

    int h1 = std::numeric_limits<int>::max();
    vector<vector<Position> >   _memorial(_size,boxes);
    int j = 0;
    while(j >= 0 && j < _size){
        int i = 0, t = 0;
        for(; i < _size && t < h1; ++i)t+=room.manhattan_distance(_memorial[j][i],target[i]);
        if(t < h1){
            h1 = t;
            if(j < _size - 1){
                ++j;
                _memorial[j] = _memorial[j - 1];
                j;
            }
        }
        if(std::next_permutation(_memorial[j].begin(),_memorial[j].end()))continue;
        else --j;
    };
    if(h1 == std::numeric_limits<int>::max())h1 = 0;

    //h2
    int h2 = std::numeric_limits<int>::max();
    for(int i = 0; i < _size; ++i){
        int k = room.manhattan_distance(room.GetManPosition(),boxes[i]) - 1;
        h2 = std::min(k,h2);
    };
    if(h2 == std::numeric_limits<int>::max())h2 = 0;

    return 0;
}

END_BOXMAN_NAMESPACE
