/////////////////////////////////////////////////////////////////////////////
// Name:        BoxMan.h
// Purpose:     BoxMan MainFrame
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/29
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#ifndef BOXMAN_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6
#define BOXMAN_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6

#include <wx/wx.h>
#include "PlayModeCanvas.h"

enum{
    MENU_GAME_EXIT = wxID_EXIT,
    MENU_GAME_SELECTGAME,
    MENU_TOOL_SOLVE,
    MENU_HELP_ABOUT,
    MENU_HELP_HOWTO
};

class BoxManFrame : public wxFrame{
private:
    BoxRoom             room;
    PlayModeCanvas*     canvas;
public:
    BoxManFrame();

    void    OnExit(wxCommandEvent&);
    void    OnUpdateUI(wxUpdateUIEvent&);
    void    UpdateStatusBar();
    void    OnAbout(wxCommandEvent&);
    void    OnHowTo(wxCommandEvent&);
    void    NewRoom(wxCommandEvent&);
    void    ToolSolve(wxCommandEvent&);
private:
    DECLARE_EVENT_TABLE()
};

#endif
