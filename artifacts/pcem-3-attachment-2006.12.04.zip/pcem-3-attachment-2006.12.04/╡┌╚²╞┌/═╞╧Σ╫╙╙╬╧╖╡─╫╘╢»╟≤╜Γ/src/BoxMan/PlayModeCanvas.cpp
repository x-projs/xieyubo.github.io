/////////////////////////////////////////////////////////////////////////////
// Name:        PlayModeCanvas.room->
// Purpose:     A Scrolled window to show the ROOM
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/29
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#include "PlayModeCanvas.h"
#include <boost/thread/thread.hpp>
#include <boost/timer.hpp>

class   Thread_ShowPath{
    PlayModeCanvas& canvas;
public:
    Thread_ShowPath(PlayModeCanvas& c):canvas(c){};
    void operator()(){
        for(MovePath::iterator iter = canvas.lastpath.begin(); iter != canvas.lastpath.end(); ++iter){
            canvas.ShowMove(*iter);
            wxMilliSleep(canvas.GOTO_SLEEP_MILLI_SEC);
        }
        canvas.lastpath.clear();
        canvas.being_busy = false;
    }
};

class   Thread_SolveRoom{
    PlayModeCanvas& canvas;
public:
    Thread_SolveRoom(PlayModeCanvas& c):canvas(c){};
    void    operator()(){
        MovePath        tmplastpath;
        SolveResult     result;
        BoxRoom oldroom = *canvas.room;
        BoxRoom tmproom = *canvas.room;
        boost::timer time;
        SolveBoxRoom(tmproom,result);
        double solvetime = time.elapsed();
        for(int i = 0; i < (int)result.size(); ++i){
            tmproom.Goto(result[i].p,tmplastpath);
            tmplastpath.push_back(result[i].d);
            tmproom.MovePush(result[i].d);
        }
        wxString    msg;
        msg.Printf("�ܹ���ʱ��%f\n",solvetime);
        if(result.size() == 0){
            msg += "֤���޽⣡\n";
        }else{
            msg += "���ɹ���\n�Ƿ�ۿ������̣�\n";
        }
        if(wxMessageBox(msg,"��Ϣ",(result.size() == 0)?wxICON_ERROR:wxYES_NO|wxICON_QUESTION ) == wxYES){
            canvas.being_busy = true;
            canvas.lastpath = tmplastpath;
            *canvas.room = oldroom;
            canvas.ShowPath();
        }
    }
};

BEGIN_EVENT_TABLE(PlayModeCanvas, wxScrolledWindow)
EVT_PAINT(PlayModeCanvas::OnPaint)
EVT_SIZE(PlayModeCanvas::OnSize)
EVT_KEY_DOWN(PlayModeCanvas::OnKey)
EVT_LEFT_DOWN(PlayModeCanvas::OnLeftMouse)
EVT_RIGHT_DOWN(PlayModeCanvas::OnRightMouse)
END_EVENT_TABLE()

PlayModeCanvas::PlayModeCanvas(wxWindow* parent, BoxRoom& theroom):room(&theroom),wxScrolledWindow(parent,-1){
    being_busy         = false;
    MASK_COLOR              = wxColour(255,255,255);
    DEF_BG_COLOR            = wxColour(0,88,88);
    CANVAS_CELL_SIZE        = 36;
    SCROLLRATE              = 1;
    GOTO_SLEEP_MILLI_SEC    = 100;

    picmap[EM_BOX].LoadFile("RES/box.bmp");
    man_pic[EAST].LoadFile("RES/man_east.bmp");
    man_pic[EAST].SetMaskColour(MASK_COLOR.Red(),MASK_COLOR.Green(),MASK_COLOR.Blue());
    man_pic[SOUTH] = man_pic[EAST].Rotate90();
    man_pic[SOUTH].SetMaskColour(MASK_COLOR.Red(),MASK_COLOR.Green(),MASK_COLOR.Blue());
    man_pic[WEST] = man_pic[SOUTH].Rotate90();
    man_pic[WEST].SetMaskColour(MASK_COLOR.Red(),MASK_COLOR.Green(),MASK_COLOR.Blue());
    man_pic[NORTH] = man_pic[WEST].Rotate90();
    man_pic[NORTH].SetMaskColour(MASK_COLOR.Red(),MASK_COLOR.Green(),MASK_COLOR.Blue());
    picmap[EM_BOX_TARGET].LoadFile("RES/tbox.bmp");
    picmap[EM_FLOOR].LoadFile("RES/floor.bmp");
    picmap[EM_FLOOR_TARGET].LoadFile("RES/tfloor.bmp");
    picmap[EM_WALL].LoadFile("RES/wall.bmp");
    cur_go = wxImage("RES/go.cur");
    cur_man_direction = EAST;

    SetBackgroundColour(DEF_BG_COLOR);
    SetCursor(cur_go);

    UpdateAll();
}

void    PlayModeCanvas::UpdateAll(){
    int _w = CANVAS_CELL_SIZE*room->GetCol();
    int _h = CANVAS_CELL_SIZE*room->GetRow();

    SetVirtualSize(_w,_h);
    wxSize  _size = GetClientSize();
    SetScrollbar(wxHORIZONTAL,0,_size.GetHeight(),_h);
    SetScrollbar(wxVERTICAL,0,_size.GetWidth(),_w);
    SetScrollRate(SCROLLRATE,SCROLLRATE);
    UpdateCanvas();
}

void    PlayModeCanvas::UpdateCanvas(){
    int _w = CANVAS_CELL_SIZE*room->GetCol();
    int _h = CANVAS_CELL_SIZE*room->GetRow();

    //ע�⣡��Note that the memory DC must be deleted (or the bitmap selected out of it) 
    //before a bitmap can be reselected into another memory DC.
    mdc_bitmap = wxImage(_w,_h);
    mdc.SelectObject(mdc_bitmap);
    mdc.SetBrush(wxBrush(DEF_BG_COLOR));
    mdc.SetPen(wxPen(DEF_BG_COLOR));
    for(int x = 0; x < int(room->GetCol()); ++x){
        for(int y = 0; y < int(room->GetRow()); ++y){
            Element e = room->GetItem(x,y);
            if(e != EM_NONE){
                mdc.DrawBitmap(picmap[e], CANVAS_CELL_SIZE*x, CANVAS_CELL_SIZE*y);
            }else{
                mdc.DrawRectangle(CANVAS_CELL_SIZE*x, CANVAS_CELL_SIZE*y,CANVAS_CELL_SIZE,CANVAS_CELL_SIZE);
            }
        }
    }
    mdc.DrawBitmap(man_pic[cur_man_direction],room->GetManPositionX()*CANVAS_CELL_SIZE,
        room->GetManPositionY()*CANVAS_CELL_SIZE,true);

    Refresh();
    lastroom = *room;
}

void    PlayModeCanvas::OnPaint(wxPaintEvent& event){
    wxSize  _size = GetClientSize();
    int _y_base(0),_x_base(0);
    if(room->GetRow()*CANVAS_CELL_SIZE < _size.GetY()){
        _y_base = (_size.GetY() - room->GetRow()*CANVAS_CELL_SIZE)/2;
    }
    if(room->GetCol()*CANVAS_CELL_SIZE < _size.GetX()){
        _x_base = (_size.GetX() - room->GetCol()*CANVAS_CELL_SIZE)/2;
    }

    wxPaintDC dc( this );
    PrepareDC( dc );
    dc.Blit(wxPoint(_x_base,_y_base),wxSize(mdc_bitmap.GetWidth(),mdc_bitmap.GetHeight()),&mdc,
        wxPoint(0,0));
}

void    PlayModeCanvas::OnSize(wxSizeEvent& event){
    UpdateAll();
}

void    PlayModeCanvas::OnKey(wxKeyEvent& event){
    if(being_busy)return;
    switch(event.GetKeyCode()){
        case    WXK_LEFT:
            ShowMove(WEST);
            break;
        case    WXK_RIGHT:
            ShowMove(EAST);
            break;
        case    WXK_UP:
            ShowMove(NORTH);
            break;
        case    WXK_DOWN:
            ShowMove(SOUTH);
            break;
        case    'S':
            ShowSolveResult();
            break;
    }
}


void    PlayModeCanvas::ShowMove(Direction d){
    bool is_not_moved = room->MovePush(cur_man_direction = d) == -1 ? true:false;
    UpdateSome();
    wxSize  _size = GetClientSize();
    int _sx = GetScrollPos(wxHORIZONTAL);
    int _msx= _sx + _size.GetX();
    int _sy = GetScrollPos(wxVERTICAL);
    int _msy= _sy + _size.GetY();
    int _mx = room->GetManPositionX() * CANVAS_CELL_SIZE;
    int _my = room->GetManPositionY() * CANVAS_CELL_SIZE;
    switch(d){
            case WEST:
                if(is_not_moved || ((_mx - _sx) < CANVAS_CELL_SIZE && _sx > 0)){
                    _sx = _sx - CANVAS_CELL_SIZE;
                    _sx = _sx > 0?_sx:0;
                    Scroll(_sx,-1);
                    break;
                }
            case EAST:
                if(is_not_moved || ((_msx - _mx) < CANVAS_CELL_SIZE && _msx < mdc_bitmap.GetWidth())){
                    _sx = _sx + CANVAS_CELL_SIZE;
                    _sx = _sx > mdc_bitmap.GetWidth()?mdc_bitmap.GetWidth():_sx;
                    Scroll(_sx,-1);
                    break;
                }
            case NORTH:
                if(is_not_moved || ((_my - _sy) < CANVAS_CELL_SIZE && _sy > 0)){
                    _sy = _sy - CANVAS_CELL_SIZE;
                    _sy = _sy > 0?_sy:0;
                    Scroll(-1,_sy);
                    break;
                }
            case SOUTH:
                if(is_not_moved || ((_msy - _my) < CANVAS_CELL_SIZE && _msy < mdc_bitmap.GetHeight())){
                    _sy = _sy + CANVAS_CELL_SIZE;
                    _sy = _sy > mdc_bitmap.GetWidth()?mdc_bitmap.GetHeight():_sy;
                    Scroll(-1,_sy);
                    break;
                }
    }
    GetParent()->UpdateWindowUI();
}

void    PlayModeCanvas::UpdateSome(){
    wxSize  _size = GetClientSize();
    int _y_base(0),_x_base(0); 
    if(room->GetRow()*CANVAS_CELL_SIZE < _size.GetY()){
        _y_base = (_size.GetY() - room->GetRow()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,NULL,&_y_base);
    }
    if(room->GetCol()*CANVAS_CELL_SIZE < _size.GetX()){
        _x_base = (_size.GetX() - room->GetCol()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,&_x_base,NULL);
    }
    for(int x = 0; x < int(room->GetCol()); ++x){
        for(int y = 0; y < int(room->GetRow()); ++y){
            Element e   = room->GetItem(x,y);
            Element oe  = lastroom.GetItem(x,y);
            if(e != oe){
                mdc.DrawBitmap(picmap[e], CANVAS_CELL_SIZE*x, CANVAS_CELL_SIZE*y);
                RefreshRect(wxRect(
                    wxPoint(_x_base + x*CANVAS_CELL_SIZE,_y_base + y*CANVAS_CELL_SIZE),
                    wxSize(CANVAS_CELL_SIZE,CANVAS_CELL_SIZE)
                    ));
            }
        }
    }
    if(room->GetManPosition() != lastroom.GetManPosition()){
        mdc.DrawBitmap(man_pic[cur_man_direction],room->GetManPositionX()*CANVAS_CELL_SIZE,
            room->GetManPositionY()*CANVAS_CELL_SIZE,true);
        mdc.DrawBitmap(picmap[room->GetItem(lastroom.GetManPositionX(),lastroom.GetManPositionY())],
            CANVAS_CELL_SIZE*lastroom.GetManPositionX(),
            CANVAS_CELL_SIZE*lastroom.GetManPositionY());
        RefreshRect(wxRect(
            wxPoint(_x_base + room->GetManPositionX()*CANVAS_CELL_SIZE,
            _y_base + room->GetManPositionY()*CANVAS_CELL_SIZE),
            wxSize(CANVAS_CELL_SIZE,CANVAS_CELL_SIZE)
            ));
        RefreshRect(wxRect(
            wxPoint(_x_base + lastroom.GetManPositionX()*CANVAS_CELL_SIZE,
            _y_base + lastroom.GetManPositionY()*CANVAS_CELL_SIZE),
            wxSize(CANVAS_CELL_SIZE,CANVAS_CELL_SIZE)
            ));
    }else{
        mdc.DrawBitmap(picmap[room->GetItem(lastroom.GetManPositionX(),room->GetManPositionY())],
            CANVAS_CELL_SIZE*room->GetManPositionX(),
            CANVAS_CELL_SIZE*room->GetManPositionY());
        mdc.DrawBitmap(man_pic[cur_man_direction],room->GetManPositionX()*CANVAS_CELL_SIZE,
            room->GetManPositionY()*CANVAS_CELL_SIZE,true);
        RefreshRect(wxRect(
            wxPoint(_x_base + room->GetManPositionX()*CANVAS_CELL_SIZE,
            _y_base + room->GetManPositionY()*CANVAS_CELL_SIZE),
            wxSize(CANVAS_CELL_SIZE,CANVAS_CELL_SIZE)
            ));
    }
    lastroom = *room;
}



void    PlayModeCanvas::OnLeftMouse(wxMouseEvent& event){
    if(being_busy)return;
    wxSize  _size = GetClientSize();
    int _y_base(0),_x_base(0); 
    if(room->GetRow()*CANVAS_CELL_SIZE < _size.GetY()){
        _y_base = (_size.GetY() - room->GetRow()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,NULL,&_y_base);
    }
    if(room->GetCol()*CANVAS_CELL_SIZE < _size.GetX()){
        _x_base = (_size.GetX() - room->GetCol()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,&_x_base,NULL);
    }
    int x = (event.GetX() - _x_base)/CANVAS_CELL_SIZE;
    int y = (event.GetY() - _y_base)/CANVAS_CELL_SIZE;

    room->GetPath(x,y,lastpath);
    ShowPath();
}

void    PlayModeCanvas::ShowPath(){
    being_busy = true;
    Thread_ShowPath thread_showgoto(*this);
    boost::thread   thrd(thread_showgoto);
}

void    PlayModeCanvas::OnRightMouse(wxMouseEvent& event){
    if(being_busy)return;
    wxSize  _size = GetClientSize();
    int _y_base(0),_x_base(0); 
    if(room->GetRow()*CANVAS_CELL_SIZE < _size.GetY()){
        _y_base = (_size.GetY() - room->GetRow()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,NULL,&_y_base);
    }
    if(room->GetCol()*CANVAS_CELL_SIZE < _size.GetX()){
        _x_base = (_size.GetX() - room->GetCol()*CANVAS_CELL_SIZE)/2;
    }else{
        CalcScrolledPosition(0,0,&_x_base,NULL);
    }
    int x = (event.GetX() - _x_base)/CANVAS_CELL_SIZE;
    int y = (event.GetY() - _y_base)/CANVAS_CELL_SIZE;

    if(int dx = (x - room->GetManPositionX())){
        BoxRoom tmproom = *room;
        Direction _d = dx>0 ? EAST:WEST;
        dx = dx>0?dx:-dx;
        int _dx = dx;
        while(--_dx)if(tmproom.MovePush(_d) == -1)return;
        while(--dx)lastpath.push_back(_d);
        ShowPath();
    }
    if(int dy = (y - room->GetManPositionY())){
        BoxRoom tmproom = *room;
        Direction _d = dy>0 ? SOUTH:NORTH;
        dy = dy>0?dy:-dy;
        int _dy = dy;
        while(--_dy)if(tmproom.MovePush(_d) == -1)return;
        while(--dy)lastpath.push_back(_d);
        ShowPath();
    }
}

void    PlayModeCanvas::ShowSolveResult(){
    Thread_SolveRoom    thread_showgoto(*this);
    boost::thread       thrd(thread_showgoto);
}
