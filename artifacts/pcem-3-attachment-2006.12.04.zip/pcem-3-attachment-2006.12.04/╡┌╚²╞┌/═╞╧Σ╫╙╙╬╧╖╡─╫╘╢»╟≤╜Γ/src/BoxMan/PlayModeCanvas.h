/////////////////////////////////////////////////////////////////////////////
// Name:        PlayModeCanvas.h
// Purpose:     A Scrolled window to show the ROOM
// Author:      Hellwolf Misty
// Modified by:
// Created:     2004/12/29
// Copyright:   (c) Hellwolf Misty
// Licence:     GNU GENERAL PUBLIC LICENSE
/////////////////////////////////////////////////////////////////////////////
#ifndef PLAYMODECANVAS_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6
#define PLAYMODECANVAS_H_3F57E0C4_BE58_457A_8794_5FEE13A0FBB6

#include <wx/wx.h>
#include <wx/image.h>
#include <stack>
#include <map>
#include "../Base/BoxRoom.h"
#include "../SolveBoxRoom/SolveBoxRoom.h"

USING_NAMESPACE_BOXMAN

class   Thread_ShowPath;
class   Thread_SolveRoom;

class PlayModeCanvas : public wxScrolledWindow{
    friend  class   Thread_ShowPath;
    friend  class   Thread_SolveRoom;
private:
    std::map<Element,wxImage>   picmap;
    wxImage                     man_pic[4];
    wxCursor                    cur_go,cur_cannotgo;
    Direction                   cur_man_direction;

    wxImage                     mdc_bitmap;
    wxMemoryDC                  mdc;

    BoxRoom*                    room;
    BoxRoom                     lastroom;
    MovePath                    lastpath;
    bool                        being_busy;
private:
    wxColour                    MASK_COLOR;
    wxColour                    DEF_BG_COLOR;
    int                         CANVAS_CELL_SIZE;
    int                         SCROLLRATE;
    int                         GOTO_SLEEP_MILLI_SEC;
public:
    PlayModeCanvas(wxWindow* parent, BoxRoom& theroom);
    void    UpdateAll();
    void    UpdateCanvas();
    void    UpdateSome();
    void    ShowMove(Direction d);
    void    ShowPath();
    void    ShowSolveResult();

    void    OnPaint(wxPaintEvent&);
    void    OnKey(wxKeyEvent&);
    void    OnSize(wxSizeEvent&);
    void    OnLeftMouse(wxMouseEvent&);
    void    OnRightMouse(wxMouseEvent&);
private:
    DECLARE_EVENT_TABLE()
};

#endif
