// Expression.cpp
// By Liqi Gao. 2005
//

#include "Expression.h"
#include <cmath>
#include <cstdlib>
#include <ctype.h>

#ifdef _DEBUG
#include <iostream>
#endif

using namespace std;

const double pi = 3.14159265358979323846;

enum TOKENS
{
	ADD='+',	SUB='-',	MUL='*',	DIV='/',
	LT='<',		GT='>',		MOD='%',	
	NONE=300,
	AND,		OR,			NOT,
	EQ,			NE,			LE,			GE,		MINUS,		POSITIVE,
	OPERATOR,
	ID,			NUM,		
	MATH_LOG,	MATH_SIN,
};

const int Expression::OPTable[21][21] = {
//=,<>, <,<=,>=, >, +, -,or, *, /,div,%,&&,NUM,~,MNS,ID, (, ), ,, $
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// ==
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// <>
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// <
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// <=
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// >=
{ 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// >
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// +
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// -
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3},	// OR
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// *
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// /
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// MOD
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// AND
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 1, 3, 3, 3},	// NUM
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// NOT
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 3, 3, 3},	// MINUS
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 1, 3, 3, 3},	// ID
{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 3},	// (
{ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 3, 2, 3},	// )
{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 3},	// ,
{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0}	// $
};

Expression::FUNCTION Expression::_MathFunName[] = {
	"&&",	AND,
	"||",	OR,
	"!",	NOT,
	"!=",	NE,
	"<=",	LE,
	">=",	GE,
	"==",	EQ,
};
const int Expression::nMathFun = sizeof( _MathFunName ) / sizeof( _MathFunName[0] );


#ifdef _DEBUG
const char token_string[][50] =
{
	"none",
	"and",	"or", "not",
	"==",	"!=",	"<=",	">=", "MINUS", "POSITIVE",
	"OPERATOR",
	"ID",	"NUM",
	"log",	"sin",
};
void display_token(int tok)
{
	if( tok < 0 )
	{
		printf("$");
	}
	else if(tok < NONE)
	{
		printf("%c", tok);
	}
	else
	{
		printf("%s", token_string[tok-NONE]);
	}
	return;
}
#endif

void Expression::Initialize()
{
	TokenTable.resize(1);
	TokenTable[0].lexem = "ans";		// a default variable
}

Expression::Expression()
{
	Initialize();
}

Expression::Expression(const char* expr)
{
	if( expr )
	{
		sLexem = expr;
	}
	Initialize();
}

Expression::Expression(const std::string& expr)
{
	sLexem = expr;
	Initialize();
}

//return: index
int Expression::Lookup(const std::string& Lexem, int &nToken)
{
	int nIndex = 0;
	// Look it up in the function table first
	for(unsigned j=0; j<nMathFun; ++j)
	{
		if( Lexem == _MathFunName[j].name )
		{
			nToken = _MathFunName[j].token;
			return 0;
		}
	}

	// then in the symbol table
	vector<TOKEN_TERM>::iterator i;
	for(i=TokenTable.begin(); i!=TokenTable.end(); ++i)
	{
		if( i->lexem == Lexem )
		{
			nIndex = i-TokenTable.begin();
			nToken = ID;
			return nIndex;
		}
	}
	return -1;
}

int	Expression::Digits()
{
	char c;
	int	 digits = 0;
	while( iLexem != iEndOfLexem )
	{
		c = *iLexem;
		if( c>='0' && c<='9' )	
		{
			++iLexem;
			digits = (digits<<3) + (digits<<1);	// digits *= 10;
			digits += int( c - '0' );
		}
		else
		{
			break;
		}
	}
	return digits;
}

double Expression::OptionalFraction()
{
	char c;
	double frac = 0;	// the fraction
	double e = 0.1;
	if( iLexem == iEndOfLexem )	return 0;
	c = *iLexem;
	if( c != '.' )	return 0;
	++iLexem;
	while( iLexem != iEndOfLexem )
	{
		c = *iLexem;
		if( c>='0' && c<='9' )
		{
			++iLexem;
			frac += e * int(c-'0');
			e = e/10;
		}
		else
			break;
	}
	return frac;
}

int Expression::OptionalExponent()
{
	int exponent = 0;
	char c;
	if( iLexem == iEndOfLexem )	return 0;
	c = *iLexem;
	if( c != 'E' && c != 'e' )	return 0;
	++ iLexem;
	c = *iLexem;
	if( c == '+' )
	{
		iLexem ++;
		exponent = Digits();
	}
	else if( c == '-' )
	{
		iLexem ++;
		exponent = - Digits();
	}
	else
	{
		exponent = Digits();
	}
	return exponent;
}

double Expression::Num()
{
	double num = Digits();
	double fraction = OptionalFraction();
	int exponent = OptionalExponent();
	
	num += fraction;
	if( exponent > 0 )
	{
		for(int i=0; i<exponent; ++i)
			num *= 10;
	}
	else
	{
		exponent = -exponent;
		for(int i=0; i<exponent; ++i)
			num /= 10;
	}
	return num;
}

int Expression::Identifier(int &nIndex)
{
	char c;
	string &lexem = sTerm;
	lexem = "";

	if( iLexem == iEndOfLexem )	return 0;
	if( !isalpha( (c=*iLexem) ) )	return 0;
	lexem.append(1, c);	++iLexem;

	while(iLexem != iEndOfLexem)
	{
		c = *iLexem;
		if( isalnum(c) )
		{
			lexem.append(1, c);
			iLexem ++;
		}
		else
			break;
	}
	int nToken;
	nIndex = Lookup( lexem, nToken );
	if( nIndex == -1 )
	{
		nIndex = TokenTable.size();
		TokenTable.push_back( TOKEN_TERM(lexem, 0) );
		return ID;
	}
	return nToken;
}


int Expression::NextToken()
{
	char c;
	int token = -1, nIndex;
	string Term;

	while(iLexem != iEndOfLexem)
	{
		c = *iLexem;
		if( c<=' ' ) ++iLexem;
		else if( isdigit(c) )
		{
			Value.d = Num();
			token = NUM;
			break;
		}
		else if( isalnum(c) )
		{
			token = Identifier( nIndex );
			Value.i = nIndex;
			break;
		}
		else if( ispunct(c) )
		{
			Term.append(1, c);	++iLexem;
			token = c;
			if( ispunct(*iLexem) )
			{
				Term.append(1, *iLexem);
				iLexem ++;
				if( (Lookup( Term, token )) == -1 )
				{
					iLexem --;
					token = c;
				}
			}
			//Recognize a minus token
			if( c == '-' && (nToken < OPERATOR || nToken == '(') )
			{	// nToken here means last token
				token = MINUS;
			}
			if( c == '+' && (nToken < OPERATOR || nToken == '(') )
			{
				token = POSITIVE;
				continue;
			}
			break;
		}
		else
		{
			token = c;
			++ iLexem;
			break;
		}
	}
	nToken = token;
	return token;
}

// index for terminators 
int Expression::tindex(const int ter)
{
	int i;
	
	int order[] = {EQ, NE, LT, LE, GE, GT, ADD, SUB, OR, MUL,
		DIV, MOD, AND, NUM, NOT, MINUS, ID, '(', ')', ',', NONE};
	const int norder = sizeof(order) / sizeof(order[0]);

	if( ter < 0 )	return norder-1;
	
	for(i = norder-1; i>=0; --i)
		if( order[i] == ter )	return i;

	return norder-1;
}

bool Expression::Translate(int tok, Expression::VALUE_TYPE &value)
{
	double n1, n2, r;
	int z1, z2;
	string term;

	switch(tok)
	{
	case MINUS:
		n1 = -num.top(); num.pop();
		num.push(n1);
		break;
	case NUM:
		num.push(Value.d);
		break;
	case ID:	// variables and functions
		if( !num.empty() )	n1 = num.top();
		term = TokenTable[value.i].lexem;
		if( term == "sin" )		{ num.pop(); r = sin(n1); }
		else if( term == "cos")	{ num.pop(); r = cos(n1); }
		else if( term == "log")	{ num.pop(); r = log(n1); }
		else if( term == "exp")	{ num.pop(); r = exp(n1); }
		else if( term == "pi" )	{ r = pi;}
		else
		{
			r = TokenTable[value.i].value.d;
		}
		num.push( r );
		break;
	case ADD:
	case SUB:
	case MUL:
	case DIV:
		if( num.empty() )	return false;
		n1 = num.top(); num.pop();
		if( num.empty() )	return false;
		n2 = num.top(); num.pop();
		switch( tok )
		{
		case ADD:	r = n1 + n2;break;
		case SUB:	r = n2 - n1;break;
		case MUL:	r = n1 * n2;break;
		case DIV:
			if( fabs(n1) < 1e-8 )	return false;	// divided by zero	
			r = n2 / n1;break;
		}
		num.push(r);
		break;
	case MOD:
		break;
	case AND:
	case OR:
	case NOT:
		if( num.empty() )	return false;
		z1 =(int) num.top(); num.pop();
		if( num.empty() )	return false;
		z2 =(int) num.top(); num.pop();
		switch( tok )
		{
		case OR:	r = z2 || z1;break;
		case AND:	r = z2 && z1;break;
		case NOT:	r = !z2;	break;
		}
		num.push(r);
		break;
	case NE:
	case EQ:
	case LT:
	case LE:
	case GE:
	case GT:
		if( num.empty() )	return false;
		z1 =(int) num.top(); num.pop();
		if( num.empty() )	return false;
		z2 =(int) num.top(); num.pop();
		switch( tok )
		{
		case NE:	r= z1 != z1;break;
		case EQ:	r= z2 == z1;break;
		case LT:	r= z2 < z1;break;
		case LE:	r= z2 <= z1; break;
		case GE:	r= z2 >= z1; break;
		case GT:	r= z2 > z1;break;
		}
		num.push(r);
		break;
	}
	return true;
}


int Expression::ParseExpression(double &dRet)
{
	while( !num.empty() )	num.pop();

	int tok;
	int X;
	double value, g;
	int op, last;
	int t1, t2;
	VALUE_TYPE	tmpValue;
	stack<double> stkValue;
	stack<int> stkOpt;
	stkValue.push(0);
	stkOpt.push(NONE);

	tok = NextToken();
	value = Value.d;
	while( 1 )
	{
		X = stkOpt.top(); g=0;
		t1 = tindex(X); t2 = tindex(tok);
		op = OPTable[t1][t2];

		if( X == ID && tok == '=' )
		{
			double dAssign = 0;
			ParseExpression( dAssign );
			tmpValue.d = stkValue.top();
			TokenTable[tmpValue.i].value.d = dAssign;
			dRet = dAssign;

			return 0;
		}
		if(op == 1 || op == 2) // < or =
		{
			stkValue.push(value);
			stkOpt.push(tok);

			tok = NextToken();
			value = Value.d;
		}
		else if(op == 3)		// >
		{	// Reduce
			do 
			{
				last = stkOpt.top();
				stkOpt.pop();
				value = stkValue.top();
				stkValue.pop();

				tmpValue.d = value;
				if( !Translate(last, tmpValue) )	return -1;
				X = stkOpt.top();
			} while( OPTable[tindex(X)][tindex(last)] != 1 );
		}
		else
		{
			if( X == NONE && (tok == -1) )
			{
				if(!num.empty())
				{
					dRet = num.top();
					num.pop();
				}
				return 0;
			}
			else
			{
#ifdef _DEBUG
				printf("Parsing error.\n");
#endif
				return -1;
			}
		}
	}
	return 0;
}


Expression::operator double()
{
	double Value = 0;
	nDepth = 0;

	iLexem = sLexem.begin();
	iEndOfLexem = sLexem.end();

	if( ParseExpression( Value ) == -1)
	{
		throw string("Error.");
	}

	TokenTable[0].value.d = Value;
	return Value;
}

void Expression::operator =(const char* expr)
{
	if( expr )	sLexem = expr;
}

void Expression::operator =(const std::string& expr)
{
	sLexem = expr;
}
