#include <string>
#include <stack>
#include <vector>

#ifndef __EXPRESSION_H__
#define __EXPRESSION_H__

#define MAX_FUN_NAME 10

class Expression
{
protected:
	struct TOKEN_TERM
	{
		std::string	lexem;
		union VALUE
		{
			double	d;		// value for variable
			int		i;
		} value;
		
		TOKEN_TERM()
		{
			value.d = 0;
		}
		TOKEN_TERM (const std::string& str, const double& d)
		{
			lexem = str;
			value.d = d;
		}
		void operator = (const TOKEN_TERM& tt)
		{
			lexem = tt.lexem;
			value.d = tt.value.d;
		}
	};
	union VALUE_TYPE
	{
		int i;
		double d;
	};
	
public:
	Expression();
	Expression(const std::string& expr);
	Expression(const char* expr);
	operator double();
	void operator =(const char* expr);
	void operator =(const std::string& expr);

protected:
	int		ParseExpression(double &Value);
	int		Lookup(const std::string& Lexem, int &nToken);
	int		Digits();
	double	OptionalFraction();
	int		OptionalExponent();
	double	Num();
	int		Identifier(int& nIndex);
	int		NextToken();

	int		tindex(const int ter);
	void	Initialize();
	bool	Translate(int tok, VALUE_TYPE &value);

private:		// data
	std::string sLexem;	// string of lexem
	std::string::iterator iLexem;	// iterator of lexem
	std::string::iterator iEndOfLexem;

	VALUE_TYPE Value;
	int nToken;		// for token
	int nDepth;		// for the brackets

	std::string sTerm;

	std::stack<double> num;			// a stack for calculating

	static const int OPTable[21][21];	// Operation table

	struct FUNCTION
	{
		char name[MAX_FUN_NAME];
		int	token;
	};
	static FUNCTION _MathFunName[];
	static const int nMathFun;

	std::vector<TOKEN_TERM> TokenTable;		// the token table

};
#endif
