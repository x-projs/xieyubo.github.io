//cmdcal.cpp
// Command Line Calculator
// By Liqi Gao. 2005
//
#ifdef _WIN32
#include <stl.h>
#endif

#include <iostream>
#include <string>
#include <fstream>
#include "Expression.h"

using namespace std;

void Help()
{
	puts("Supported functions:");
	puts("  sin, cos, exp, log");
	puts("Supported constants:");
	puts("  pi");
	puts("Hits:");
	puts("  log n(x) = log(x)/log(n)");
	puts("  x^y = exp(y*log(x))");
	puts("  default variable: ans");
}

char* RemoveReturn(char *str)
{
	size_t len = strlen(str);
	size_t i = len-1;
	while( i>=0 && (str[i] == '\r' || str[i] == '\n') )
	{
		i--;
	}
	str[i+1] = '\0';
	return str;
}

int main(int argc, char* argv[])
{
	ofstream out("history.txt");
	puts("Command Line Calculator V0.1    By Liqi Gao.");
	puts("Type ? to get help.");
	
	const int bufsize = 1000;
	Expression expr;
	char buf[bufsize];
	double Value;
	cout<<">";
	while(gets(buf))
	{
		RemoveReturn( buf );
		
		try
		{
			if(buf[0] == 0)	break;
			if(strcmp(buf, "?") == 0)
			{
				Help(); 
			}
			else
			{
				expr = buf;
				Value = (double)expr;
				printf("ans = %.5f\n", Value);
				out << buf << endl;
			}
		}
		catch(string& msg)
		{
			cerr << msg << endl;
		}
		cout<<">";
	}
	out.close();
	return 0;
}
