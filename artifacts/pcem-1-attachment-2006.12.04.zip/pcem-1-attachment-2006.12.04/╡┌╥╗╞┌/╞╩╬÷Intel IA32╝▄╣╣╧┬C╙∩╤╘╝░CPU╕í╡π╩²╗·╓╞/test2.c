/* ------------------- test2.c --------------------- */
union U{
        float f ;
        struct{
                unsigned char x1 ;
                unsigned char x2 ;
                unsigned char x3 ;
                unsigned char x4 ;
        } ;
} u ;

int main()
{
        u.x1 = 0x00 ;
        u.x2 = 0x00 ;
        u.x3 = 0x50 ;
        u.x4 = 0x00 ;

        printf( "%e\n " , u.f ) ;
        return 0 ;
}

