#include <stdio.h>
double f(int x)
{
        return 1.0 / x ;
}

void main()
{
        double a , b , c;
        int i ;
        a = f(10) ;
        b = f(10) ;
        c = f(10) ;
        i = a == b ;
        printf( "%d\n" , i ) ;
}

