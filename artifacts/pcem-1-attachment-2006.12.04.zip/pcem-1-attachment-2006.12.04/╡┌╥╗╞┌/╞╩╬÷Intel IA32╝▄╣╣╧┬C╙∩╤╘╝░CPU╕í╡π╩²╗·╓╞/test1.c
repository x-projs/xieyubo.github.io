#include <stdio.h>
main()
{
	float a;
	double b;
	a = 123456.789e4;
	b = 123456.789e4;
	printf("%f\n%f\n",a,b);
}

