/* ------------------- test4.c ----------------- */
int main()
{
        float f = 3.25 + 1e10;
        f = f - 1e10 ;
        printf( "%f\n",f ) ;
        return 0 ;
}

