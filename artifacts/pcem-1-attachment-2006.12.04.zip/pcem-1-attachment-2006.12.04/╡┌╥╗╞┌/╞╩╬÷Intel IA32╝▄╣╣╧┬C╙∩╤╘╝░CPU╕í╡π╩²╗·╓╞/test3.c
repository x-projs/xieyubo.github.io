/* ------------------------ test3.c -------------------- */
union U{
        float f ;
        struct{
                unsigned char x1 ;
                unsigned char x2 ;
                unsigned char x3 ;
                unsigned char x4 ;
        } ;
} u ;

int main()
{
        u.f = -0.625 ;

        printf( "%2x %2x %2x %2x\n",u.x4,u.x3,u.x2,u.x1) ;
        return 0 ;
}

