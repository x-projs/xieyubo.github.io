#include <stdio.h>
#include <string.h>
#include <errno.h>  
#include <unistd.h>
#include <sys/socket.h>
#include <linux/if_packet.h>
#include <sys/types.h>  
#include <linux/in.h>
#include <linux/if_ether.h>
#include <net/if.h>
#include <sys/ioctl.h>

char sendbuf[] = "\x00\x08\xE2\x83\xA0\x0A\x00\x30\x48\x21\xB9\x81\x08\x00\x45\x10\x00\x3C\xF1\x09\x40\x00\x40\x06\xE0\xC3\xCA\x76\xF3\xEE\xCA\x76\xE0\x02\x80\x05\x00\x17\x73\x61\x99\x46\x00\x00\x00\x00\xA0\x02\x16\xD0\xD2\x8D\x00\x00\x02\x04\x05\xB4\x04\x02\x08\x0A\x00\xB7\x68\x4F\x00\x00\x00\x00\x01\x03\x03\x00";

int send_to_wire(int sock,char *buf,int size)
{
 	  struct sockaddr_ll  dst;
	  dst.sll_family = PF_PACKET;
    dst.sll_protocol = htons(ETH_P_ALL);
    dst.sll_ifindex = 2; /* interface "eth0" */
    dst.sll_pkttype=PACKET_HOST;
    dst.sll_hatype = IP_HDRINCL ;
    memset(dst.sll_addr,0,sizeof(dst.sll_addr));
		return size == sendto(sock,buf,size,0,(struct sockaddr*) &dst,sizeof(dst));
}

int main(int argc, char **argv) 
{
  int sock, n,tmp;
  u_char buffer[2048];
  unsigned char *iphead, *ethhead;
  struct ifreq ethreq;
  
  if ( (sock=socket(PF_PACKET, SOCK_RAW,htons(ETH_P_ALL)))<0)
  {
    perror("socket");
    exit(1);
  }
  strncpy(ethreq.ifr_name,"eth0",IFNAMSIZ);
  if (ioctl(sock,SIOCGIFFLAGS,&ethreq)==-1) 
  {
    perror("ioctl Error");
    close(sock);
    exit(1);
  }
  ethreq.ifr_flags|=IFF_PROMISC;
  if (ioctl(sock,SIOCSIFFLAGS,&ethreq)==-1) 
  {
    perror("ioctl Error");
    close(sock);
    exit(1);
  }
	int i;
  for(i =0;i<100;i++)
  {
    struct sockaddr from;
    int len;
    int i;
    n = recvfrom(sock,buffer,2048,0,&from,&len);
    
    if(buffer[12] == 0x08 && buffer[13] == 0x00) //IP Protocol
    {
		    iphead = buffer+14; 
		    if (*iphead==0x45) 
		    {	
		      printf(
		      			 "%d.%d.%d.%d",
		             iphead[12],iphead[13],
		             iphead[14],iphead[15]
		             );
		      printf(" (%d)--> ",n);
		      printf(
		      			 "%d.%d.%d.%d\n",
		             iphead[16],iphead[17],
		             iphead[18],iphead[19]
		             );
		      continue;
		    }
    }
    
    ethhead = buffer;
    printf(
    			 "%02X:%02X:%02X:%02X:%02X:%02X",
           ethhead[0],ethhead[1],ethhead[2],
           ethhead[3],ethhead[4],ethhead[5]
           );
    printf(" (%d)--> ",n);
    printf(
    			 "%02X:%02X:%02X:%02X:%02X:%02X\n",
           ethhead[6],ethhead[7],ethhead[8],
           ethhead[9],ethhead[10],ethhead[11]
           );
  }
  
  if( send_to_wire(sock,sendbuf,sizeof(sendbuf)) )
	  printf("Packet Sent\n");

	return 0;
}
