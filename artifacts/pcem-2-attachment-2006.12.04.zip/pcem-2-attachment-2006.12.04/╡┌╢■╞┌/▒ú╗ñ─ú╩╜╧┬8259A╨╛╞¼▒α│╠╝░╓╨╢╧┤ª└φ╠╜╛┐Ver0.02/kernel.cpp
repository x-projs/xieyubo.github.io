#include "system.h"
#include "video.h"

extern "C" void Pyos_Main()
{
  /* ϵͳ��ʼ�� */
  class_pyos_System::Init() ;
  class_pyos_Video::ClearScreen() ;
  class_pyos_Video::PrintMessage( "Welcome to Pyos :)" ) ;
  for(;;);
}

