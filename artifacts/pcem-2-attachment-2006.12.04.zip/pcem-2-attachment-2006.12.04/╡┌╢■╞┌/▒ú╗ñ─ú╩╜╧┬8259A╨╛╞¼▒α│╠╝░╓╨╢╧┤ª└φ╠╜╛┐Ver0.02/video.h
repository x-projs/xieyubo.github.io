#ifndef _PYOS_VIDEO_H_
#define _PYOS_VIDEO_H_

enum enum_pyos_Color{ clBlack , clBlue , clGreen , clCyan , clRed , clMagenta , clBrown ,
             clLightGray , clDarkGray , clLightBlue , clLightGreen , clLightCyan ,
             clLightRed , clLightMagenta , clYellow , clWhite } ;

class class_pyos_Position{
  public:
    class_pyos_Position( unsigned short x = 0 , unsigned short y = 0 ) : X( x ) , Y( y ) {} ;
    unsigned short X ;
    unsigned short Y ;
};

class class_pyos_Video{
  protected:
    class_pyos_Video(){} ;
    static unsigned char GetLogicalColorFromFrontColorAndBackColor( enum_pyos_Color front_color , enum_pyos_Color back_color ) ;
    static void SetCursorPosition() ;
    static class_pyos_Position CursorCurrentPosition ;
  public:
    static void Init() ;
    //static class_pyos_Position GetCursorPosition() ;
    //static void SetCursorPosition( class_pyos_Position pos ) ;
    static void SetCursorPosition( unsigned short x , unsigned short y ) ;
    static void ClearScreen() ;
    static void PrintMessage( char *msg , enum_pyos_Color FrontColor = clWhite , enum_pyos_Color BackColor = clBlack ) ;
    static void PrintMessage( char msg , enum_pyos_Color FrontColor = clWhite , enum_pyos_Color BackColor = clBlack ) ;
    
    static enum_pyos_Color BackColor ;
    static enum_pyos_Color FrontColor ;
};

#endif 

